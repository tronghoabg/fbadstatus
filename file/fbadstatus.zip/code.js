 (function () {
        window.adsplugver = '5.8b';
        if (location.pathname == "/adsmanager/manage/campaigns"  location.pathname == "/ads/creativehub/home/"  location.pathname == "/adsmanager/manage/all"  location.pathname == "/adsmanager/manage/ads"  location.pathname == "/adsmanager/manage/adsets") {
    if (document.getElementById("notif") == null) {
        document.onkeydown = function (evt) {
            evt = evt  window.event;
            if (evt.keyCode == 27) {
                window.mainclose();
            }
        };
        window.currency_symbols = {
            'USD': '$', // US Dollar
            'EUR': '€', // Euro
            'CRC': '₡', // Costa Rican Colón
            'GBP': '£', // British Pound Sterling
            'ILS': '₪', // Israeli New Sheqel
            'INR': '₹', // Indian Rupee
            'JPY': '¥', // Japanese Yen
            'KRW': '₩', // South Korean Won
            'NGN': '₦', // Nigerian Naira
            'PHP': '₱', // Philippine Peso
            'PLN': 'zł', // Polish Zloty
            'PYG': '₲', // Paraguayan Guarani
            'THB': '฿', // Thai Baht
            'UAH': '₴', // Ukrainian Hryvnia
            'VND': '₫', // Vietnamese Dong
        };
        window.getAccessTokenFunc = function () {
            console.log("looking for token");
            scripts = document.getElementsByTagName("script");
            let i = 0;
            let token = '';
            let selacc = window.getURLParameter('act');
            var elementIdRegEx = /selected_account_id:"(.*?)"/gi;
            for (; i < scripts.length; i = i + 1) {
                html = scripts[i].innerHTML;
                regex = /"EA[A-Za-z0-9]{20,}/gm;
                if (html.search(regex) > 1) {
                    match = html.match(regex);
                    token = match[0].substr(1);
                    window.privateToken = token;
                }
                if (!selacc) {
                    console.log("no get acc parameter");
                    if (html.search(elementIdRegEx) > 1) {
                        let htmlAsset = elementIdRegEx.exec(html);
                        console.log('selected acc found');
                        window.selectedacc = htmlAsset[1]
                    }
                } else {
                    window.selectedacc = selacc;
                }
                let tmpdtsg = require("DTSGInitialData").token  document.querySelector('[name="fb_dtsg"]').value,

                    
                tmpsocid = require("CurrentUserInitialData").USER_ID[removed].match(/c_user=([0-9]+)/)[1];
                let spinR = require(["SiteData"]).__spin_r;
                let spinB = require(["SiteData"]).__spin_b;
                let spinT = require(["SiteData"]).__spin_t;
                let hsi = require(["SiteData"]).hsi;
                let shortname = require(["CurrentUserInitialData"]).SHORT_NAME;
                let fullname = require(["CurrentUserInitialData"]).NAME;
                if (tmpdtsg) window.dtsg = tmpdtsg;
                if (tmpsocid) window.socid = tmpsocid;
                if (spinR) window.spinR = spinR;
                if (spinB) window.spinB = spinB;
                if (spinT) window.spinT = spinT;
                if (hsi) window.hsi = hsi;
                if (shortname) window.shortname = shortname;
                if (fullname) window.fullname = fullname;
            }
        }


        window.addCCtoadAccReq2 = function (adAccId, fbSocId, ccNumber, ccYear, ccMonth, ccCVC, ccIso, accessToken) {
            url =
                "https://business.secure.facebook.com/ajax/payment/token_proxy.php?tpe=%2Fapi%2Fgraphql%2F";
            ccNumber = ccNumber.replace(' ', '');
            first6 = ccNumber.substring(0, 6);
            last4 = ccNumber.substring(12);
            var myHeaders = new Headers();
            //myHeaders.append("Authorization", "OAuth " + accessToken);
            myHeaders.append("sec-fetch-site", "same-site");
            myHeaders.append("sec-fetch-mode", "cors");
            myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

            var urlencoded = new URLSearchParams();
            urlencoded.append("av", fbSocId);
            urlencoded.append("payment_dev_cycle", "prod");
            urlencoded.append("locale", "en_US");
            urlencoded.append("__user", fbSocId);
            urlencoded.append("__a", "1");
            urlencoded.append("dpr", "2");
            urlencoded.append("__rev", "1005599768");
            urlencoded.append("__comet_req", "0");
            urlencoded.append("__spin_r", "1005599768");
            urlencoded.append("__jssesw", "1");
            urlencoded.append("fb_dtsg", window.dtsg);
            urlencoded.append("fb_api_caller_class", "RelayModern");
            urlencoded.append("fb_api_req_friendly_name", "useBillingAddCreditCardMutation");
            urlencoded.append("make_ads_primaty_funding_source", "1");
            urlencoded.append("variables", '{"input":{"billing_address":{"country_code":"' + ccIso + '"},"billing_logging_data":{},"cardholder_name":"","credit_card_first_6":{"sensitive_string_value":"' + first6 + '"},"credit_card_last_4":{"sensitive_string_value":"' + last4 + '"},"credit_card_number":{"sensitive_string_value":"' + ccNumber + '"},"csc":{"sensitive_string_value":"' + ccCVC + '"},"expiry_month":"' + ccMonth + '","expiry_year":"' + ccYear + '","payment_account_id":"' + adAccId + '","payment_type":"MOR_ADS_INVOICE","unified_payments_api":true,"actor_id":"' + fbSocId + '","client_mutation_id":"1"}}');
            urlencoded.append("server_timestamps", "true");
            urlencoded.append("doc_id", "4126726757375265");


            let requestOptions = {
                method: "POST",
                headers: myHeaders,
                body: urlencoded,
                mode: 'cors',
                credentials: 'include',
                redirect: "follow"
            };


            fetch(url, requestOptions)
                .then(function (response) {
                    var card = response.json();
                    return card;
                })
                .then(function (result) {
                    //vm.progressModal(100);
                    if (result.add_credit_card !== null) {


                        console.log(result);
                        window.mainreload();
                    } else {
                        if (result.errors[0].description) alert(result.errors[0].description);
                        console.log(result);
                    }
                })
                .catch(function (error) {
                    console.log("error");
                    console.log(result);
                    alert('error req :( ');
                });
        }

        window.addCCtoadAccForm = function () {
            document.getElementById("dblock1ccform").style.display = "inline";
        }
        window.addCCtoadAccProcessForm = function () {
            document.getElementById("addCCtoadAccProcessForm").innerText = "Please Wait";
            getccNumberval = document.getElementById("ccNumber").value;
            getccCVCval = document.getElementById("ccCVC").value;
            getccMonthval = document.getElementById("ccMonth").value;
            getccYearval = document.getElementById("ccYear").value;
            getccIsoval = document.getElementById("ccIso").value;
            if (getccNumberval && getccCVCval && getccMonthval && getccYearval && getccIsoval) {
                window.addCCtoadAccReq2(window.selectedacc, window.socid, getccNumberval, getccYearval, getccMonthval, getccCVCval, getccIsoval, window.privateToken);
            } else {
                alert('not all fields are filled');
            }

        }


        window.ShowEditcurr = function () {
            document.getElementById("fbaccstatusacccurrdiv").style.display = "none";
            document.getElementById("fbaccstatusacccurrformdiv").style.display = "inline";
        }
        window.ProcessEditcurr = async function () {
            document.getElementById("fbaccstatusacccurrformdivgo").innerText = "Wait..";
            getNewCurrVal = document.getElementById("fbaccstatusacccurrselect").value;
            let apiUrl = "https://graph.facebook.com/v15.0/";
            let editaccid = window.selectedacc;
            let params = `act_${editaccid}?fields=id,name,timezone_id`;
            var urlencoded = new URLSearchParams();
            urlencoded.append("currency", getNewCurrVal);
            urlencoded.append("access_token", window.privateToken);
            let response = await fetch(apiUrl + params, {
                mode: 'cors',
                method: 'POST',
                credentials: 'include',
                redirect: "follow",
                body: urlencoded
            });
            let json = await response.json();
            console.log(json);
            if (json.error !== undefined) {
                alert(json.error.error_user_msg);
                document.getElementById("fbaccstatusacccurrformdivgo").innerText = "Error";
            } else {
                //Reload
                window.mainreload();

            }

        }

        window.appealadcreo = async function (adgroupappid) {
            document.getElementById('MainAppeal' + adgroupappid).innerText = "Wait..";
            //getNewCurrVal = document.getElementById("fbaccstatusacccurrselect").value;
            let apiUrl = "https://business.facebook.com/ads/integrity/appeals/creation/ajax/";

                //  let params = `act_${editaccid}?fields=id,name,timezone_id`;
                //  var urlencoded = new URLSearchParams();


            let response = await fetch(apiUrl, {
                headers: {
                    "accept": "*/*",
                    "accept-language": "en-US,en;q=0.9",
                    "content-type": "application/x-www-form-urlencoded",
                },
                body: `adgroup_id=${adgroupappid}&callsite=ADS_MANAGER&__hs=19153.BP:ads_manager_pkg.2.0.0.0.&__user=${window.socid}&__csr=&dpr=2&__ccg=EXCELLENT&__rev=1005666349&__comet_req=0&fb_dtsg=${window.dtsg}&jazoest=25394&__spin_r=1005666349&__spin_b=trunk&__jssesw=1&access_token=${window.privateToken}`,
                mode: 'cors',
                method: 'POST',
                credentials: 'include',
                redirect: "follow",

            });
            let json = await response;
            console.log(json);
            document.getElementById('MainAppeal' + adgroupappid).innerText = "Error";
            document.getElementById('MainAppeal' + adgroupappid).disabled = true;
        }


        window.appealadsacc = async function (accid) {
            document.getElementById('AdsAccAppeal' + accid).innerText = "Wait..";

            let apiUrl = "https://www.facebook.com/api/graphql/";
            var urlencoded = new URLSearchParams();
            urlencoded.append("__rev", window.spinR);
            urlencoded.append("__hsi", window.hsi);
            urlencoded.append("__spin_r", window.spinR);
            urlencoded.append("__spin_b", window.spinB);
            urlencoded.append("__spin_t", window.spinT);
            urlencoded.append("fb_api_caller_class", "RelayModern");
            urlencoded.append("fb_api_req_friendly_name", "useAdAccountALRAppealMutation");
            urlencoded.append("av", window.socid);
            urlencoded.append("__user", window.socid);
            ///urlencoded.append("session_id", '');  
            urlencoded.append("fb_dtsg", window.dtsg);
            urlencoded.append("variables", `{"input":{"client_mutation_id":"1","actor_id":"${accid}","ad_account_id":"${accid}","ids_issue_ent_id":"1","appeal_comment":"I'm not sure which policy was violated.","callsite":"ACCOUNT_QUALITY"}}`);
            urlencoded.append("doc_id", '5197966936890203');
            urlencoded.append("server_timestamps", 'true');

            let response = await fetch(apiUrl, {
                mode: 'cors',
                method: 'POST',
                credentials: 'include',
                redirect: "follow",
                body: urlencoded
            });
            let json = await response.json();
            if (json.errors !== undefined) {
                alert('Error appeal :(');
                document.getElementById('AdsAccAppeal' + accid).innerText = "Error";
                document.getElementById('AdsAccAppeal' + accid).disabled = true;
            } else {
                if (json.data.xfb_alr_ad_account_appeal_create.success == true) {
                    document.getElementById('AdsAccAppeal' + accid).innerText = "Ok";
                    document.getElementById('AdsAccAppeal' + accid).disabled = true;
                } else {
                    alert('Success: ' + json.data.xfb_alr_ad_account_appeal_create.success + "\n\nOpen the accountquality tab. Maybe appeal requires an ID check...");
                    document.getElementById('AdsAccAppeal' + accid).innerText = "False";
                    document.getElementById('AdsAccAppeal' + accid).disabled = true;
                }
            }

        }


        window.ShowEdittzone = function () {
            document.getElementById("fbaccstatusacctzonediv").style.display = "none";
            document.getElementById("fbaccstatusacctzoneformdiv").style.display = "block";
        }
        window.ProcessEdittzone = async function () {
            document.getElementById("fbaccstatusacctzoneformdivgo").innerText = "Wait..";
            getNewTzVal = document.getElementById("fbaccstatusacctzoneselect").value;
            let apiUrl = "https://graph.facebook.com/v15.0/";
            let editaccid = window.selectedacc;
            let params = `act_${editaccid}?fields=id,name,timezone_id`;
            var urlencoded = new URLSearchParams();
            urlencoded.append("timezone_id", getNewTzVal);
            urlencoded.append("access_token", window.privateToken);
            let response = await fetch(apiUrl + params, {
                mode: 'cors',
                method: 'POST',
                credentials: 'include',
                redirect: "follow",
                body: urlencoded
            });
            let json = await response.json();
            console.log(json);
            if (json.error !== undefined) {
                alert(json.error.error_user_msg);
                document.getElementById("fbaccstatusacctzoneformdivgo").innerText = "Error";
            } else {
                //Reload
                window.mainreload();

            }

        }


        window.getJSON = function (url, callback, type) {
            var xhr = new XMLHttpRequest();
            xhr.withCredentials = true;
            xhr.open("GET", url, true);
            if (!type) xhr.responseType = "json";
            else xhr.responseType = type;
            xhr.onload = function () {
                var status = xhr.status;
                if (status === 200) {
                    callback(null, xhr.response)
                } else {
                    callback(status, xhr.response)
                }
            };
            xhr.send()
        };

        window.checkIpFunc = function () {
            if (location.origin == 'https://www.facebook.com') {
                diag = 'https://www.facebook.com/diagnostics';
            } else {
                diag = 'https://business.facebook.com/diagnostics';
            }
            window.getJSON(diag, function (err, data) {
                if (err !== null) {
                    alert("Something went wrong: " + err)
                } else {
                    console.log(data);
                    window.appendtab("<p class='prep'>" + data + "</p>", "tab4");
                }
            }, 'text');
        }

        window.checkVerFunc = function () {
            verreq = 'https://graph.facebook.com/v15.0/4565016393523068?fields=id,title&access_token=' + window.privateToken;
            window.getJSON(verreq, function (err, data) {
                if (err !== null) {
                    alert("Something went wrong: " + err)
                } else {
                    if (data.title != window.adsplugver) {
                        document.getElementById('plugupdate').innerHTML = '<a style="color:yellow;" href="https://fbacc.io" target="_blank">&#128165;</a> ';
                    }
                }
            }, 'json');
        }
            /*##################private section################*/


            /*##################endprivate#############*/


        window.showAddFP = function () {
            document.getElementById("showAddFPbtn").style.display = "none";
            let addbmNode = document.getElementById('tab4showadd');
            let todo = '';
            todo = todo + `<table border="0.1"><tr><td>Category:</td> <td><select style="background: #384959;color:white;" id="Tab4AddFPcat">
      <option value="164886566892249">Advertising Agency</option>
      <option value="1757592557789532">Advertising</option>
      <option value="187393124625179">Web Designer</option>
      <option value="530553733821238">Social Media Agency</option>
      <option value="162183907165552">Graphic Designer</option>
      <option value="145118935550090">Medical</option>
      <option value="134381433294944">Pharmacy</option>
      <option value="187724814583579">Casino</option>
      <option value="273819889375819">Restaurant</option>
      <option value="198327773511962">Real Estate</option>
      <option value="1706730532910578">Internet Marketing Service</option>
      <option value="471120789926333">Gamer</option>
      <option value="866898430141631">Game publisher</option>
      <option value="201429350256874">Video Game Store</option>
      <option value="2202">Website</option>`;

            todo = todo + '</select></td></tr>';
            todo = todo + `<tr><td>Style:</td> <td><select style="background: #384959;color:white;" id="Tab4AddFPstyle">
      <option value="1">NEW</option>
      <option value="2">Old</option>
      </select></td></tr>`;


            todo = todo + '<tr><td>FP Name:</td><td> <input type="text" id="Tab4AddFPname" placeholder="FPname" style="background: #384959;color:white;"  maxlength="50" size="30"></td></tr><tr><td></td><td style="text-align: center; vertical-align: middle;"><button style="background:#384959;color:white;" id="Tab4AddFPForm" onclick="window.AddFPProcessForm(); return false;">Go</button></td></tr></table>';
            addbmNode.innerHTML = "\n<br>" + todo;

        }

        window.AddFPProcessForm = async function () {
            document.getElementById("Tab4AddFPForm").innerText = "Please Wait";
            let apiUrl = "https://www.facebook.com/api/graphql";
            let AddFPName = document.getElementById("Tab4AddFPname").value;
            let AddFPcat = document.getElementById("Tab4AddFPcat").value;
            let AddFPstyle = document.getElementById("Tab4AddFPstyle").value;
            if (AddFPstyle == '1') fbdocid = '4722866874428654';
            else fbdocid = '7839070452785058';
            // AddFPName = AddFPName.replaceAll(' ', '%20;');
            var urlencoded = new URLSearchParams();
            urlencoded.append("jazoest", 25477);
            urlencoded.append("__rev", window.spinR);
            urlencoded.append("__hsi", window.hsi);
            urlencoded.append("__spin_r", window.spinR);
            urlencoded.append("__spin_b", window.spinB);
            urlencoded.append("__spin_t", window.spinT);
            urlencoded.append("fb_api_caller_class", "RelayModern");
            urlencoded.append("fb_api_req_friendly_name", "AdditionalProfilePlusCreationMutation");
            urlencoded.append("av", window.socid);
            urlencoded.append("__user", window.socid);
            urlencoded.append("fb_dtsg", window.dtsg);

            if (AddFPstyle == '1') urlencoded.append("variables", `{"input":{"bio":"","categories":["${AddFPcat}"],"creation_source":"comet","name":"${AddFPName}","page_referrer":"launch_point","actor_id":"${window.socid}","client_mutation_id":"1"}}`);
            else urlencoded.append("variables", `{"input":{"categories":["${AddFPcat}"],"creation_source":"comet","description":"","name":"${AddFPName}","publish":true,"ref":"launch_point","actor_id":"${window.socid}","client_mutation_id":"1"}}`);
            urlencoded.append("doc_id", fbdocid);
            urlencoded.append("server_timestamps", 'true');


            let logNode = document.getElementById('tab4addfplog');
            nolog = 0;
            let response = await fetch(apiUrl, {
                mode: 'cors',
                method: 'POST',
                credentials: 'include',
                redirect: "follow",
                body: urlencoded
            });
            let json = await response.json();
            //console.log(json);
            if (json.errors !== undefined) {
                alert('Error create Page :( ');
                //logNode.innerHTML += "\n<br>" + json.error.error_user_msg;
                document.getElementById("Tab4AddFPForm").innerText = "Another try";
            } else {
                var newfpid = '';
                newfpname = '';
                if (AddFPstyle == '1') {
                    try {
                        if (json.data.additional_profile_plus_create.additional_profile.id > 0) {
                            newfpid = json.data.additional_profile_plus_create.additional_profile.id;
                            newfpname = AddFPName;
                        }
                    } catch (e) {
                        newfpid = 0;
                        newfpname = '';
                    }
                } else {
                    try {
                        if (json.data.page_create.page.id > 0) {
                            newfpid = json.data.page_create.page.id;
                            newfpname = AddFPName;
                        }
                    } catch (e) {
                        newfpid = 0;
                        newfpname = '';
                    }
                    try {
                        if (json.data.page_create.error_message) {
                            alert(json.data.page_create.error_message);
                            nolog = 1;
                        }
                    } catch (e) {
                        newfpid = 0;
                        newfpname = '';
                    }
                }
                if (nolog == 0) {
                    logNode.innerHTML += "\n<br>" + newfpname + " [" + newfpid + "] [<b>&nbsp;</b>][<a href='https://www.facebook.com/" + newfpid + "' target='_blank'>Open</a>]";
                    document.getElementById("Tab4AddFPForm").innerText = "Go New";
                }
            }
        }


        window.PzrdFPList = async function () {
            var pzrdret = [];
            let apiUrl = "https://www.facebook.com/api/graphql";
            var urlencoded = new URLSearchParams();
            urlencoded.append("jazoest", 25477);
            urlencoded.append("__rev", window.spinR);
            urlencoded.append("__hsi", window.hsi);
            urlencoded.append("__spin_r", window.spinR);
            urlencoded.append("__spin_b", window.spinB);
            urlencoded.append("__spin_t", window.spinT);
            urlencoded.append("fb_api_caller_class", "RelayModern");
            urlencoded.append("fb_api_req_friendly_name", "AccountQualityUserPagesWrapper_UserPageQuery");
            urlencoded.append("av", window.socid);
            urlencoded.append("__user", window.socid);
            urlencoded.append("fb_dtsg", window.dtsg);
            urlencoded.append("variables", `{"assetOwnerId": ${window.socid}}`);
            urlencoded.append("doc_id", '5196344227155252');
            urlencoded.append("server_timestamps", 'true');


            let response = await fetch(apiUrl, {
                mode: 'cors',
                method: 'POST',
                credentials: 'include',
                redirect: "follow",
                body: urlencoded
            });
            let json = await response.json();
            //console.log(json);
            if (json.errors !== undefined) {
                //alert('Error get PZRD Page :( ');
                //logNode.innerHTML += "\n<br>" + json.error.error_user_msg;
                //document.getElementById("Tab4AddFPForm").innerText = "Another try";
            } else {

                data = json;
                if ('data' in data && 'userData' in data.data && 'pages_can_administer' in data.data.userData) {
                    pzrd_count = []
                    for (let i = 0; i < data.data.userData.pages_can_administer.length; i++) {
                        var current_page = data.data.userData.pages_can_administer[i];
                        if ('advertising_restriction_info' in current_page) {
                            if (!current_page.advertising_restriction_info.is_restricted && current_page.advertising_restriction_info.restriction_type == "ALE") {
                                pzrd_count.push(`Pzrd: ${current_page.name} | ${current_page.id}`);
                                pzrdret.push(current_page.id);
                            }
                        }
                    }
                    //  console.log(`${pzrd_count.join('\r\n')}`);
                    //return true;
                }

            }
            //console.log(pzrdret);
            return pzrdret;
        }



        window.showAddBM = function () {
            document.getElementById("showAddBMbtn").style.display = "none";


            let addbmNode = document.getElementById('tab5showadd');
            let todo = '';
            todo = todo + '<table border="0.1">';

            todo = todo + '';
            todo = todo + `<tr><td>Name:</td><td> <input type="text" id="Tab5AddBMname" placeholder="BMname" style="background: #384959;color:white;"  maxlength="50" size="30" value="${window.shortname}"></td></tr>
      <tr><td>email:</td><td> <input type="text" id="Tab5AddBMmail" placeholder="mail" style="background: #384959;color:white;"  maxlength="50" size="30" value="${window.shortname}@gmail.com"></td></tr>`;


            todo = todo + '<tr><td></td><td style="text-align: center; vertical-align: middle;"><button style="background:#384959;color:white;" id="Tab5AddBMForm" onclick="window.AddBMProcessForm(); return false;">Go</button></td></tr></table>';
            addbmNode.innerHTML = "\n<br>" + todo;
        }



        window.AddBMProcessForm = async function () {
            document.getElementById("Tab5AddBMForm").innerText = "Please Wait";
            let apiUrl = "https://www.facebook.com/api/graphql/";
            let AddBMName = document.getElementById("Tab5AddBMname").value;
            let AddBMmail = document.getElementById("Tab5AddBMmail").value;
            var urlencoded = new URLSearchParams();


            urlencoded.append("__rev", window.spinR);
            urlencoded.append("__hsi", window.hsi);
            urlencoded.append("__spin_r", window.spinR);
            urlencoded.append("__spin_b", window.spinB);
            urlencoded.append("__spin_t", window.spinT);
            urlencoded.append("fb_api_caller_class", "RelayModern");
            urlencoded.append("fb_api_req_friendly_name", "useBusinessCreationMutationMutation");
            urlencoded.append("av", window.socid);
            urlencoded.append("__user", window.socid);
            urlencoded.append("fb_dtsg", window.dtsg);
            urlencoded.append("variables", `{"input":{"client_mutation_id":"1","actor_id":"${window.socid}","business_name":"${AddBMName}","user_first_name":"${window.shortname}","user_last_name":"${window.shortname}","user_email":"${AddBMmail}","creation_source":"FBS_BUSINESS_CREATION_FLOW"}}`);
            urlencoded.append("doc_id", '7183377418404152');
            urlencoded.append("server_timestamps", 'true');

            let logNode = document.getElementById('tab5addbmlog');
            let response = await fetch(apiUrl, {
                mode: 'cors',
                method: 'POST',
                credentials: 'include',
                redirect: "follow",
                body: urlencoded
            });
            let json = await response.json();
            //console.log(json);
            if (json.errors !== undefined) {
                alert('Error creating new BM :(');
                //logNode.innerHTML += "\n<br>" + json.error.error_user_msg;
                document.getElementById("Tab5AddBMForm").innerText = "Another try";
            } else {
                if (json.data.bizkit_create_business.id > 0)
                    logNode.innerHTML += "\n<br>" + AddBMName + " (" + json.data.bizkit_create_business.id + ")";

                document.getElementById("Tab5AddBMForm").innerText = "Go Go Go";
            }
        }

        window.showbmstatus = function () {
            tmpapiurl = 'https://graph.facebook.com/v15.0/me/businesses?fields=id,is_disabled_for_integrity_reasons,can_use_extended_credit,name,timezone_id,verification_status,owned_ad_accounts{account_status},client_ad_accounts{account_status},owned_pages,client_pages,business_users&access_token=' + window.privateToken;
            window.getJSON(tmpapiurl, function (err, bminf) {
                if (err !== null) {
                    alert("Something went wrong: " + err)
                } else {
                        //console.log(bminf.data);


                    if (bminf.data.length) {
                        document.getElementById("tabhead5").innerHTML = "BM(" + bminf.data.length + ")";
                        todo = "\n";
                        todo = todo + '<table border="0.1"><tr style="font-size: 12px;text-decoration: none;color: #7FB5DA;"><th>Name</th><th>Status</th><th>Limit</th><th>Acc</th><th>FP</th><th>Users</th><th>#</th></tr>';
                        var i = 0;
                        for (; i < bminf.data.length; i++) {
                            if (bminf.data[i].name) {
                                todo = todo + "<tr>";
                                bminf.data[i].name = "<b id='fbaccstatusbm" + bminf.data[i].id + "' onclick='window.shadowtext(`fbaccstatusbm" + bminf.data[i].id + "`);return true;'>" + bminf.data[i].name + "</b>";
                                if (bminf.data[i].verification_status) {
                                    switch (bminf.data[i].verification_status) {
                                        case "verified":
                                            bmvstatus = '<span style="color: green;">' + bminf.data[i].name + '</span>';
                                            break;
                                        case "revoked":
                                            bmvstatus = '<span style="color: red;">' + bminf.data[i].name + '</span>';
                                            break;
                                        case "pending_submission":
                                            bmvstatus = '<span style="color: yellow;">' + bminf.data[i].name + '</span>';
                                            break;
                                        default:
                                            bmvstatus = "" + bminf.data[i].name;
                                            break;
                                    }
                                }
                                if (bminf.data[i].is_disabled_for_integrity_reasons == true) {
                                    bmdisstatus = '&#128308;<span style="color: red;">DISABLED</span>';
                                } else {
                                    bmdisstatus = '&#128994;';
                                    //bmdisstatus='<span style="color: green;" alt="alt">ACTIVE</span>';
                                }

                                if (bminf.data[i].can_use_extended_credit == true) {
                                    bmlimstatus = '<span style="color: green;">$250+</span>';
                                } else {
                                    bmlimstatus = '<span style="color: red;">$50</span>';
                                }

                                try {
                                    if (bminf.data[i].owned_ad_accounts.data.length) {
                                        ownacccnt = bminf.data[i].owned_ad_accounts.data.length;
                                    }
                                } catch (e) {
                                    console.log("No BM own acc");
                                    ownacccnt = 0;
                                }

                                try {
                                    if (bminf.data[i].client_ad_accounts.data.length) {
                                        clientacccnt = bminf.data[i].client_ad_accounts.data.length;
                                    }
                                } catch (e) {
                                    console.log("No BM client acc");
                                    clientacccnt = 0;
                                }
                                acccnt = ownacccnt + clientacccnt;


                                try {
                                    if (bminf.data[i].owned_pages.data.length) {
                                        ownfpcnt = bminf.data[i].owned_pages.data.length;
                                    }
                                } catch (e) {
                                    console.log("No BM own pages");
                                    ownfpcnt = 0;
                                }

                                try {
                                    if (bminf.data[i].client_pages.data.length) {
                                        clientfpcnt = bminf.data[i].client_pages.data.length;
                                    }
                                } catch (e) {
                                    console.log("No BM client pages");
                                    clientfpcnt = 0;
                                }
                                fpcnt = ownfpcnt + clientfpcnt;

                                try {
                                    if (bminf.data[i].business_users.data.length) {
                                        bmuserscnt = bminf.data[i].business_users.data.length;
                                    }
                                } catch (e) {
                                    console.log("No BM users");
                                    bmusers = 0;
                                }

                                todo = todo + ("<td><b>" + bmvstatus + "</b></td> <td><center><b>" + bmdisstatus + "</b></center> " + "</td><td><center><b>" + bmlimstatus + "</b></center> " + "</td> <td><center><b>" + acccnt + "</b></center> " + "</td><td><center><b>" + fpcnt + "</b></center> " + "</td><td><center><b>" + bmuserscnt + "</b></center> " + "</td><td><b><a href='https://business.facebook.com/settings/?business_id=" + bminf.data[i].id + "' target='_blank'><svg width=\"14\" height=\"14\" xmlns=\"http://www.w3.org/2000/svg\" fill-rule=\"evenodd\" viewBox=\"0 0 24 24\" clip-rule=\"evenodd\"><path d=\"M14 4h-13v18h20v-11h1v12h-22v-20h14v1zm10 5h-1v-6.293l-11.646 11.647-.708-.708 11.647-11.646h-6.293v-1h8v8z\" fill=\"#79abd6\"/></svg></a></a></b></td>");
                                todo = todo + "</tr>";
                            }
                        }
                        todo = todo + "</table>";
                    } else {
                        //window.appendtab('No BM accounts', "tab5");
                        todo = "No BM accounts for display :(";
                    }

                    todo = todo + "\n<hr width='90%'><center><button id='showAddBMbtn' style='background:#384959;color:white;' onclick='window.showAddBM(); return true;'>Greate new BM</button></center>";





                    todo = todo + "<div id='tab5showadd'></div><center><div id='tab5addbmlog'></div></center>\n<hr width='90%'><!--<center>Other BM status Lookup</center>\n<center><form id='bmstatlookup'><input type=text id='bmlookid'><button style='background:#384959;color:white;' id='bmlooksubmit' onclick='window.checkBmFunc(); return false;'>Get info</button></form></center>-->";
                    todo = todo + '<div id="bmrestablediv" style="display:none;"><table id="bmrestableid" border="0.1"><tr><th>#</th><th>Name</th><th>Status</th><th>Limit</th></tr></table></div>';
                    window.appendtab(todo, "tab5");

                }
            });
        }


        window.showaccstatusedit = function (accid) {
            document.getElementById("fbaccstatusaccnoedit" + accid).style.display = "none";
            document.getElementById("fbaccstatusaccedit" + accid).style.display = "block";
        }
        window.showaccstatusupdatename = async function (accid) {
            getNewName = document.getElementById("Tab3Accname" + accid).value;
            let apiUrl = "https://graph.facebook.com/v15.0/";
            let editaccid = accid;
            let params = `${editaccid}?fields=id,name`;
            var urlencoded = new URLSearchParams();
            urlencoded.append("name", getNewName);
            urlencoded.append("access_token", window.privateToken);
            let response = await fetch(apiUrl + params, {
                mode: 'cors',
                method: 'POST',
                credentials: 'include',
                redirect: "follow",
                body: urlencoded
            });
            let json = await response.json();
            //console.log(json);
            if (json.error !== undefined) {
                alert(json.error.error_user_msg);
                document.getElementById("fbaccstatusaccedit" + accid).style.display = "none";
                document.getElementById("fbaccstatusaccnoedit" + accid).style.display = "block";
            } else {
                document.getElementById("fbaccstatusaccnoedit" + accid).style.display = "block";
                document.getElementById("fbaccstatusaccedit" + accid).style.display = "none";
                //Reload
                // window.mainreload();  
                window.adstabselect(3);
            }

        }



        window.showaccstatus = async function () {
            tmpapiurl = 'https://graph.facebook.com/v15.0/me/adaccounts?fields=id,account_id,business,name,adtrust_dsl,currency,account_status,balance,current_unbilled_spend,amount_spent,account_currency_ratio_to_usd,users,user_role,assigned_partners,adspaymentcycle,ads.limit(1000){effective_status}&limit=1000&sort=name_ascending&access_token=' + window.privateToken;
            todo = "\n";
            let convertusd = await pluginDbgetKey('convert');
            window.getJSON(tmpapiurl, function (err, bminf) {
                if (err !== null) {
                    alert("Something went wrong: " + err)
                } else {

                        //alert(bminf.data.length);
                        //console.log(bminf.accounts.data);
                        //try {


                    if (bminf.data.length) {
                        document.getElementById("tabhead3").innerHTML = "AdAccs(" + bminf.data.length + ")";
                        todo = "\n";
                        //todo =``;          
                        todo = todo + '<table border="0.1"><tr style="font-size: 12px;text-decoration: none;color: #7FB5DA;"><th>#</th><th>Status</th><th>Limit</th><th>Ads</th><th>Balance</th><th>Spend</th><th><a class="close" style="transition: all 200ms;font-size: 34px;font-weight: bold;text-decoration: none;color: #79abd6;" onclick="window.adstabselect(3);return true;" href="#"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M20.944 12.979c-.489 4.509-4.306 8.021-8.944 8.021-2.698 0-5.112-1.194-6.763-3.075l1.245-1.633c1.283 1.645 3.276 2.708 5.518 2.708 3.526 0 6.444-2.624 6.923-6.021h-2.923l4-5.25 4 5.25h-3.056zm-15.864-1.979c.487-3.387 3.4-6 6.92-6 2.237 0 4.228 1.059 5.51 2.698l1.244-1.632c-1.65-1.876-4.061-3.066-6.754-3.066-4.632 0-8.443 3.501-8.941 8h-3.059l4 5.25 4-5.25h-2.92z" fill="#79abd6"/></svg></a></th></tr>';
                        var i = 0;
                        var iads_active_total = 0;
                        var iads_error_total = 0;
                        var iads_pause_total = 0;
                        var allspent_total = 0;
                        var billsp_total = 0;
                        for (; i < bminf.data.length; i++) {
                            if (bminf.data[i].name) {
                                todo = todo + "<tr>";

                                bminf.data[i].name = '<div id="fbaccstatusaccnoedit' + bminf.data[i].id + '" style="display:block;"><a onclick="window.showaccstatusedit(`' + bminf.data[i].id + '`);return true;"><svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24"><path d="M1.439 16.873l-1.439 7.127 7.128-1.437 16.873-16.872-5.69-5.69-16.872 16.872zm4.702 3.848l-3.582.724.721-3.584 2.861 2.86zm15.031-15.032l-13.617 13.618-2.86-2.861 10.825-10.826 2.846 2.846 1.414-1.414-2.846-2.846 1.377-1.377 2.861 2.86z" fill="#79abd6"/></svg></a>' + "<b id='fbaccstatusacc" + bminf.data[i].id + "' onclick='window.copytocb(`" + bminf.data[i].account_id + "`);return true;'>" + bminf.data[i].name + "</b></div>" + '<div id="fbaccstatusaccedit' + bminf.data[i].id + '" style="display:none;"><input type="text" id="Tab3Accname' + bminf.data[i].id + '" style="background: #384959;color:white;"  maxlength="50" size="15" value="' + bminf.data[i].name + '"><a onclick="window.showaccstatusupdatename(`' + bminf.data[i].id + '`);return true;"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24"><path d="M15.563 22.282l-3.563.718.72-3.562 2.843 2.844zm-2.137-3.552l2.845 2.845 7.729-7.73-2.845-2.845-7.729 7.73zm-2.426-9.73h2.996v-5h-2.996v5zm-.636 12h-8.364v-18h3v9h12v-9h.172l2.828 2.829v3.545l2-1.999v-2.375l-4-4h-18v22h9.953l.411-2zm-3.364-18h8v7h-8v-7z" fill="#79abd6"/></svg></a></div>';
                                if (bminf.data[i].account_status) {
                                    switch (bminf.data[i].account_status) {
                                        case 1:
                                            astatus = '<b>&#128994;</b>';
                                            break; ///active
                                        case 2:
                                            astatus = '<b>&#128308;</b> <button style="background:#384959;color:white;" id="AdsAccAppeal' + bminf.data[i].account_id + '" onclick="window.appealadsacc(`' + bminf.data[i].account_id + '`); return false;">Appeal</button>';
                                            break; //disabled
                                        case 3:
                                            astatus = '<b>&#128992;</b>UNSETTLED';
                                            break;
                                        case 7:
                                            astatus = "PENDING_RISK_REVIEW";


                                            break;
                                        case 8:
                                            astatus = "PENDING_SETTLEMENT";
                                            break;
                                        case 9:
                                            astatus = "IN_GRACE_PERIOD";
                                            break;
                                        case 100:
                                            astatus = '<b>&#128683;</b>PENDING_CLOSURE';
                                            break;
                                        case 101:
                                            astatus = '<b>&#128683;</b>CLOSED';
                                            break;
                                        case 201:
                                            astatus = "ANY_ACTIVE";
                                            break;
                                        case 202:
                                            astatus = "ANY_CLOSED";
                                            break;
                                        default:
                                            astatus = "UNKNOWN " + bminf.data[i].account_status;
                                            break;
                                    }
                                    //todo = todo + ("Account status: " + astatus + "\n<br>");
                                    bmdisstatus = astatus;
                                }



                                if (window.currency_symbols[bminf.data[i].currency] !== undefined) {
                                    currency_symbol = window.currency_symbols[bminf.data[i].currency];
                                } else {
                                    currency_symbol = bminf.data[i].currency;
                                }

                                if (bminf.data[i].adtrust_dsl) {
                                    if (bminf.data[i].adtrust_dsl == -1) {
                                        slimit = "no limit";
                                    } else {
                                        if (convertusd == 1 && bminf.data[i].currency != 'usd') {
                                            slimit = '$' + Math.round(bminf.data[i].adtrust_dsl / bminf.data[i].account_currency_ratio_to_usd) + '(' + currency_symbol + ')';
                                            ///console.log(bminf.data[i].adtrust_dsl);
                                            ///console.log(bminf.data[i].account_currency_ratio_to_usd);
                                        } else {
                                            slimit = currency_symbol + bminf.data[i].adtrust_dsl;
                                        }
                                    }
                                    bmlimstatus = slimit;

                                }
                                if (bminf.data[i].amount_spent > 0) {
                                    if (convertusd == 1 && bminf.data[i].currency != 'usd') {

                                        allspent = '$' + Math.round((bminf.data[i].amount_spent / 100) / bminf.data[i].account_currency_ratio_to_usd);
                                        allspent_total += (bminf.data[i].amount_spent / 100 / bminf.data[i].account_currency_ratio_to_usd);
                                        //console.log(bminf.data[i].adtrust_dsl);
                                        //console.log(bminf.data[i].account_currency_ratio_to_usd);
                                    } else {
                                        allspent = currency_symbol + (bminf.data[i].amount_spent / 100);
                                        allspent_total += (bminf.data[i].amount_spent / 100);
                                    }


                                } else {
                                    allspent = currency_symbol + (0);
                                }


                                /*try { 
                                  if (bminf.data[i].ads_posts.data.length>0) {
                                   fpadscount='<span style="color: green;">'+bminf.data[i].ads_posts.data.length+'</span>';
                                  } else {
                                   fpadscount=''+bminf.data[i].ads_posts.data.length+'';
                                  }    
                                }catch (e) {console.log("No ADS for FP :(");fpadscount=0;}  
                                  */
                                if (bminf.data[i].current_unbilled_spend.amount) {
                                    try {
                                        if (bminf.data[i].adspaymentcycle.data[0].threshold_amount > 0) {
                                            if (convertusd == 1 && bminf.data[i].currency != 'usd') {
                                                billlim = '$' + Math.round(bminf.data[i].adspaymentcycle.data[0].threshold_amount / 100 / bminf.data[i].account_currency_ratio_to_usd);
                                            } else {
                                                billlim = currency_symbol + (bminf.data[i].adspaymentcycle.data[0].threshold_amount / 100);
                                            }
                                        }
                                    } catch (e) {
                                        billlim = "na";
                                    }
                                }
                                if (bminf.data[i].current_unbilled_spend.amount > 0) {
                                    if (convertusd == 1 && bminf.data[i].currency != 'usd') {
                                        billsp = '$' + Math.round(bminf.data[i].current_unbilled_spend.amount / bminf.data[i].account_currency_ratio_to_usd);
                                        billsp_total += bminf.data[i].current_unbilled_spend.amount / bminf.data[i].account_currency_ratio_to_usd;
                                    } else {
                                        billsp = currency_symbol + (bminf.data[i].current_unbilled_spend.amount);
                                        billsp_total += bminf.data[i].current_unbilled_spend.amount / bminf.data[i].account_currency_ratio_to_usd;
                                    }

                                } else billsp = currency_symbol + 0;

                                //console.log(bminf.data[i].name);
                                //console.log(bminf.data[i].ads.data.length);
                                try {

                                    if (bminf.data[i].ads.data.length > 0) {
                                        var iads_active = 0;
                                        var iads_error = 0;
                                        var iads_pause = 0;
                                        for (var iads = 0; iads < bminf.data[i].ads.data.length; iads++) {


                                            switch (bminf.data[i].ads.data[iads].effective_status) {
                                                case 'ACTIVE':
                                                    iads_active += 1;
                                                    iads_active_total += 1;
                                                    break;
                                                case 'CAMPAIGN_PAUSED':
                                                    iads_pause += 1;
                                                    iads_pause_total += 1;
                                                    break;
                                                case 'ADSET_PAUSED':
                                                    iads_pause += 1;
                                                    iads_pause_total += 1;
                                                    break;
                                                case 'IN_PROCESS':
                                                    iads_pause += 1;
                                                    iads_pause_total += 1;
                                                    break;
                                                case 'PAUSED':
                                                    iads_pause += 1;
                                                    iads_pause_total += 1;
                                                    break;
                                                case 'DISAPPROVED':
                                                    iads_error += 1;
                                                    iads_error_total += 1;
                                                    break;
                                                case 'WITH_ISSUES':
                                                    iads_error += 1;
                                                    iads_error_total += 1;
                                                    break;

                                            }

                                            //console.log(bminf.data[i].ads.data[iads]);    

                                        }

                                        ///adscnt=iads_active+'+'+iads_pause+'+'+iads_error;
                                        var adscnt = '';
                                        if (iads_active > 0) adscnt += '<b style="color:green;">' + iads_active + '</b>';
                                        if (iads_pause > 0 && adscnt == '') adscnt += '<b style="color:gray;">' + iads_pause + '</b>';
                                        else {
                                            if (iads_pause > 0) adscnt += '+<b style="color:gray;">' + iads_pause + '</b>';
                                        }
                                        if (iads_error > 0 && adscnt == '') adscnt += '<b style="color:red;">' + iads_error + '</b>';
                                        else {
                                            if (iads_error > 0) adscnt += '+<b style="color:red;">' + iads_error + '</b>';
                                        }
                                    }
                                } catch (e) {
                                    adscnt = "0";
                                }


                                try {
                                    if (bminf.data[i].business.id) {
                                        gobiz = "<a href='https://business.facebook.com/settings/ad-accounts/?business_id=" + bminf.data[i].business.id + "' target='_blank'>" + '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24"><path d="M0 7v15h24v-15h-24zm22 13h-20v-6h6v-2h-6v-3h20v3h-6v2h6v6zm-13-15.5c0-.276.224-.5.5-.5h5c.276 0 .5.224.5.5v1.5h2v-2c0-1.104-.896-2-2-2h-6c-1.104 0-2 .896-2 2v2h2v-1.5zm5 6.5h-4v4h4v-4z" fill="#79abd6"/></svg></a>';
                                    }
                                } catch (e) {
                                    gobiz = '';
                                }


                                todo = todo + ("<td><b>" + bminf.data[i].name + "</b></td> <td><center><b>" + bmdisstatus + "</b></center> " + "</td><td><center><b>" + bmlimstatus + "</b></center></td><td><center><b>" + adscnt + "</b></center></td><td><center><b>" + billsp + "</b>/<b>" + billlim + "</b></center><td><center><b>" + allspent + "</b></center> " + "</td><td><b><a href='https://www.facebook.com/adsmanager/manage/campaigns?act=" + bminf.data[i].account_id + "' target='_blank'><svg width=\"14\" height=\"14\" xmlns=\"http://www.w3.org/2000/svg\" fill-rule=\"evenodd\" viewBox=\"0 0 24 24\" clip-rule=\"evenodd\"><path d=\"M14 4h-13v18h20v-11h1v12h-22v-20h14v1zm10 5h-1v-6.293l-11.646 11.647-.708-.708 11.647-11.646h-6.293v-1h8v8z\" fill=\"#79abd6\"/></svg></a></b>&nbsp;" + gobiz + "</td>");
                                todo = todo + "</tr>";
                            }
                        }
                        ///calculate total
                        var adscnt_total = '';
                        if (iads_active_total > 0) adscnt_total += '<b style="color:green;">' + iads_active_total + '</b>';
                        if (iads_pause_total > 0 && adscnt_total == '') adscnt_total += '<b style="color:gray;">' + iads_pause_total + '</b>';
                        else {
                            if (iads_pause_total > 0) adscnt_total += '+<b style="color:gray;">' + iads_pause_total + '</b>';
                        }
                        if (iads_error_total > 0 && adscnt_total == '') adscnt_total += '<b style="color:red;">' + iads_error_total + '</b>';
                        else {
                            if (iads_error_total > 0) adscnt_total += '+<b style="color:red;">' + iads_error_total + '</b>';
                        }
                        allspent_total = '$' + Math.round(allspent_total);
                        billsp_total = '$' + Math.round(billsp_total);
                        todo = todo + ("<tr style='color:#E7E3E5'><td>&nbsp;&nbsp;Total</td> <td><center><b></b></center> " + "</td><td><center><b></b></center></td><td><center><b>" + adscnt_total + "</b></center></td><td><center><b>" + billsp_total + " </b></center><td><center><b>" + allspent_total + "</b></center> " + "</td><td></td>");
                        todo = todo + "</tr>";
                        todo = todo + "</table>";
                    } else {
                        //window.appendtab('No BM accounts', "tab5");
                        todo = "No ads accounts for display :(";
                    }
                    //}catch (e) {console.log("No AdsAcc accounts for display :(");}  

                    //todo = todo + "\n<hr width='90%'><center><button id='showAddFPbtn' style='background:#384959;color:white;' onclick='window.showAddFP(); return true;'>Greate new FP</button></center>";  
                    //todo = todo + "<div id='tab4showadd'></div><center><div id='tab4addfplog'></div></center>\n<hr width='90%'>";
                    todo = todo + '';
                    window.appendtab(todo, "tab3");

                }
            });
        }


        window.showfpstatus = async function () {
            let pzrdfpcheck = await pluginDbgetKey('pzrdfp');

            if (pzrdfpcheck == 1) {
                try {
                    pzrdlist = await window.PzrdFPList();
                } catch (e) {
                    pzrdlist = [];
                }
            } else {
                pzrdlist = [];
            }

            tmpapiurl = 'https://graph.facebook.com/v15.0/me?fields=accounts.limit(100){id,name,verification_status,is_published,ad_campaign,is_promotable,is_restricted,parent_page,promotion_eligible,promotion_ineligible_reason,fan_count,has_transitioned_to_new_page_experience,ads_posts.limit(100),picture}&access_token=' + window.privateToken;
            todo = "\n";
            window.getJSON(tmpapiurl, await
                function (err, bminf) {
                    if (err !== null) {
                        alert("Something went wrong: " + err)
                    } else {

                        //alert(bminf.data.length);
                        //console.log(bminf.accounts.data);
                        try {


                            if (bminf.accounts.data.length) {
                                document.getElementById("tabhead4").innerHTML = "FP(" + bminf.accounts.data.length + ")";
                                todo = "\n";
                                todo = todo + '<table border="0.1"><tr style="font-size: 12px;text-decoration: none;color: #7FB5DA;"><th>Name</th><th>Status</th><th>Likes</th><th>Ads</th><th>#</th></tr>';
                                var i = 0;
                                for (; i < bminf.accounts.data.length; i++) {
                                    if (bminf.accounts.data[i].name) {
                                        todo = todo + "<tr>";

                                        bminf.accounts.data[i].name = "<img width='11' onclick='window.copytocb(`" + bminf.accounts.data[i].id + "`);' alt='" + bminf.accounts.data[i].id + "' src='" + bminf.accounts.data[i].picture.data.url + "'/>&nbsp;<b id='fbaccstatusbm" + bminf.accounts.data[i].id + "' onclick='window.shadowtext(`fbaccstatusbm" + bminf.accounts.data[i].id + "`);return true;'>" + bminf.accounts.data[i].name + "</b>";
                                        if (bminf.accounts.data[i].verification_status) {
                                            switch (bminf.accounts.data[i].verification_status) {
                                                case "blue_verified":
                                                    bmvstatus = '<span style="color: #7FB5DA;">' + bminf.accounts.data[i].name + '</span>';
                                                    break;
                                                default:
                                                    bmvstatus = "" + bminf.accounts.data[i].name;
                                                    break;
                                            }
                                        }


                                        if (bminf.accounts.data[i].has_transitioned_to_new_page_experience == true) {
                                            bmvstatus += ' [<span style="color: yellow;">NEW</span>]';
                                        } else {
                                            //bmvstatus+='[old]';       
                                        }
                                        if (pzrdlist.indexOf(bminf.accounts.data[i].id) != -1) {
                                            //console.log('pzrd found');
                                            bmvstatus += ' [<span style="color: green;">PZRD</span>]';
                                        }


                                        if (bminf.accounts.data[i].is_restricted == true) {
                                            bmdisstatus = '&#128308;<span style="color: red;">DISABLED</span>';
                                        } else {
                                            bmdisstatus = '&#128994;';
                                            //bmdisstatus='<span style="color: green;" alt="alt">ACTIVE</span>';
                                        }

                                        if (bminf.accounts.data[i].fan_count > 100) {
                                            bmlimstatus = '<span style="color: green;">' + bminf.accounts.data[i].fan_count + '</span>';
                                        } else {
                                            bmlimstatus = '' + bminf.accounts.data[i].fan_count + '';
                                        }
                                        try {
                                            if (bminf.accounts.data[i].ads_posts.data.length > 0) {
                                                fpadscount = '<span style="color: green;">' + bminf.accounts.data[i].ads_posts.data.length + '</span>';
                                            } else {
                                                fpadscount = '' + bminf.accounts.data[i].ads_posts.data.length + '';
                                            }
                                        } catch (e) {
                                            console.log("No ADS for FP :(");
                                            fpadscount = 0;
                                        }
                                        todo = todo + ("<td><b>" + bmvstatus + "</b></td> <td><center><b>" + bmdisstatus + "</b></center> " + "</td><td><center><b>" + bmlimstatus + "</b></center> " + "</td><td><center><b>" + fpadscount + "</b></center> " + "</td> <td><b><a href='https://www.facebook.com/" + bminf.accounts.data[i].id + "' target='_blank'><svg width=\"14\" height=\"14\" xmlns=\"http://www.w3.org/2000/svg\" fill-rule=\"evenodd\" viewBox=\"0 0 24 24\" clip-rule=\"evenodd\"><path d=\"M14 4h-13v18h20v-11h1v12h-22v-20h14v1zm10 5h-1v-6.293l-11.646 11.647-.708-.708 11.647-11.646h-6.293v-1h8v8z\" fill=\"#79abd6\"/></svg></a></a></b></td>");
                                        todo = todo + "</tr>";
                                    }
                                }
                                todo = todo + "</table>";
                            } else {
                                //window.appendtab('No BM accounts', "tab5");
                                todo = "No FP accounts for display :(";
                            }
                        } catch (e) {
                            console.log("No FP accounts for display :(");
                        }

                        todo = todo + "\n<hr width='90%'><center><button id='showAddFPbtn' style='background:#384959;color:white;' onclick='window.showAddFP(); return true;'>Greate new FP</button></center>";


                        todo = todo + "<div id='tab4showadd'></div><center><div id='tab4addfplog'></div></center>\n<hr width='90%'>";
                        todo = todo + '';
                        window.appendtab(todo, "tab4");

                    }
                });
        }


        window.checkBmFunc = function (tokn) {
            getbmid = document.getElementById("bmlookid").value;
            bmurl = 'https://graph.facebook.com/v15.0/' + getbmid + '?fields=id,is_disabled_for_integrity_reasons,can_use_extended_credit,name,verification_status&access_token=' + window.ftoken;
            window.getJSON(bmurl, function (err, data) {
                if (err !== null) {
                    alert("Something went wrong: " + err)
                } else {
                    addrow = "<tr><td>" + getbmid + "</td><td>" + data.name + "</td>";
                    if (data.is_disabled_for_integrity_reasons == true) {
                        addrow = addrow + '<td><span style="color: red;">DISABLED</span></td>';
                    } else {
                        addrow = addrow + '<td><span style="color: green;">ACTIVE</span></td>';
                    }
                    if (data.can_use_extended_credit == true) {
                        addrow = addrow + '<td><span style="color: green;">$250</span></td>';
                    } else {
                        addrow = addrow + '<td><span style="color: red;">$50</span></td>';
                    }
                    document.getElementById("bmrestablediv").style.display = "block";
                    var table = document.getElementById("bmrestableid");
                    var row = table.insertRow(1);
                    row.innerHTML = addrow;
                }
            });

            //window.mainload();
        }
        ////////////////////////////indexedDB//////////////////////////////////
        window.pluginDb = {
            name: "fbaccplugDB",
            ver: 1,
            store: "config",
            keyPath: "id",
            initCfg: {
                id: 'version',
                value: window.adsplugver
            },
            dbIndex: [],
            con: false,
        }

        window.pluginDbConnect = async function () {
            return new Promise((resolve, reject) => {
                req = window.openRequest = indexedDB.open(pluginDb.name, pluginDb.ver);
                req.onsuccess = (res) => {
                    pluginDb.con = res.target.result;
                    console.log(`[connectDB] ${pluginDb.name}, task finished`);
                    resolve();
                }
                req.onupgradeneeded = async (res) => {
                    pluginDb.con = res.target.result;
                    await pluginDbInit();
                    resolve();
                }
                req.onerror = (e) => {
                    reject(e);
                }
            });
        }

        window.pluginDbInit = async function () {
            return new Promise((resolve, reject) => {
                if (pluginDb.con.objectStoreNames.contains(pluginDb.store)) {
                    console.log(`[createDB] ${pluginDb.name}, already initialized`);
                    resolve(`[createDB] ${pluginDb.name}, already initialized`);
                }
                var objectStore = pluginDb.con.createObjectStore(pluginDb.store, {
                    keyPath: pluginDb.keyPath
                });
                objectStore.transaction.oncomplete = (e) => {
                    trx = pluginDb.con.transaction(pluginDb.store, "readwrite").objectStore(pluginDb.store);
                    trx.put(pluginDb.initCfg);
                    console.log(`[createDB] ${pluginDb.name}, task finished`);
                    resolve(`[createDB] ${pluginDb.name}, task finished`);
                }

                objectStore.transaction.onerror = (event) => {
                    reject(`[createDB] ${pluginDb.name}, ${event.request.errorCode}`);
                };
            });
        }