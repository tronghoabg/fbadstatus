initHTML()
main()

async function reqAPI(url, method, mode) {
    let response = await fetch(
        url,
        {
            method: method,
            mode: mode,
            credentials: 'include',
            headers:{
                "Content-type": "application/json",
                "referer": "https://business.facebook.com/adsmanager/manage/accounts"
            },
        })
    let html = await response.text().then((res) => res)
    return html;
}

window.onload = function(){
    setTimeout(autoClose, 15000)
}

function autoClose(){
    let ftable = document.querySelector('#fmain')
    ftable.style.opacity = 0
    ftable.style.visibility='hidden'
    ftable.style.width = '0'
}


async function main(){
    var url = window.location.href
    var flag = url.indexOf('act=')
    var act = ''
    if(flag>-1){
        act = url.split('act=')[1].split('&')[0];
        var token = await getToken2()
        let obj = await getACT_INFO(token.token, token.fbdt, act)
        renderHtml(obj)
    }
}

function renderHtml(obj){
    let list = document.getElementsByClassName("list-li")
    var i = 0;

    for(var result in obj){
        if(Array.isArray(obj[result])){
            var type_currency = obj.currency
            if (obj[result][0]== '-' || obj[result][0]=='No limit'){
                type_currency = ''
            }
            list[i].innerHTML+=`<div><span id='r'>${obj[result][0]} ${type_currency}</span><span id='g'>${obj[result][1]} ${(type_currency=='' ? '' : 'USD')}</span></div>`
        }else{
            list[i].innerHTML+=`<p>${obj[result]}</p>`
        }
        i++
    }
    fadeOutEffect('load')
}

function fadeOutEffect(id) {
    var fadeTarget = document.getElementById(id);
    var fadeEffect = setInterval(function () {
        if (!fadeTarget.style.opacity) {
            fadeTarget.style.opacity = 1;
        }
        if (fadeTarget.style.opacity > 0) {
            fadeTarget.style.opacity -= 0.1;
            fadeTarget.style.visibility = 'hidden';
        } else {
            clearInterval(fadeEffect);
        }
    }, 150);
}

function initHTML(){
    let html = 
    `
    <div id="fbadstatus">
        <img class ="flogo"  src=${chrome.runtime.getURL('icon/icon.png')} alt="fbadstatus">
    </div>
    <div class="main preloading" id="fmain">
        <div id="load">
            <img src=${chrome.runtime.getURL('icon/loading.gif')}>
        </div>
        <div class="header">
            <img src=${chrome.runtime.getURL('icon/logoWeb.png')} alt="FbAdStatus.Com">
            <img id="fclose" src=${chrome.runtime.getURL('icon/close.png')} alt="X">
        </div>
        <ul class="list" id="list-show">
            <li class="list-li">
                <p>Trạng thái TK</p>
            </li>
            <li class="list-li">
                <p>ID</p>
            </li>
            <li class="list-li">
                <p>Tên tài khoản</p>
            </li>
            <li class="list-li">
                <p>Dư nợ</p>
            </li>
            <li class="list-li">
                <p>Ngưỡng</p>
            </li>
            <li class="list-li">
                <p>Giới hạn</p>
            </li>
            <li class="list-li">
                <p>Chi tiêu</p>
            </li>
            <li class="list-li">
                <p>Admin</p>
            </li>
            <li class="list-li">
                <p>Loại tiền tệ</p>
            </li>
            <li class="list-li">
                <p>Loại tài khoản</p>
            </li>
            <li class="list-li">
                <p>Ngày tạo</p>
            </li>
            <li class="list-li">
                <p>Múi giờ</p>
            </li>
            <li class="list-li">
                <p>Tên múi giờ</p>
            </li>
    </ul>
    </div>
    `
    let wrapperObj = document.querySelector('body>div')
    wrapperObj.insertAdjacentHTML('beforeend', html)
    let btnShow = document.querySelector('#fbadstatus')
    let btnClose = document.querySelector('#fclose')
    let ftable = document.querySelector('#fmain')
    window.flag = true
    btnShow.onclick = function(){
        flag = ftable.style.opacity
        if(flag==0){
            ftable.style.opacity = 1
            ftable.style.visibility='visible'
            ftable.style.width = '300px'
        }else{
            ftable.style.opacity = 0
            ftable.style.visibility='hidden'
            ftable.style.width = '0'
        }
    }
    btnClose.onclick = function(){
        ftable.style.opacity = 0
        ftable.style.visibility='hidden'
        ftable.style.width = '0'
    }
}

async function getToken2() {
    var html_src = document.documentElement.outerHTML;
    regex = /"EA[A-Za-z0-9]{20,}/gm;
    match = html_src.match(regex);
    token = match[0].substr(1);
    fbdt= html_src.split('["DTSGInitData",[],{"token":"')[1].split('"')[0]
    obj ={
        token: token,
        fbdt: fbdt
    }
    return obj;
}

async function getACT_INFO(token , fbdt , act) {
    let rowInfo = ['account_id', 'account_status', 'name', 'adtrust_dsl', 'currency', 'balance', 'amount_spent',]
    let url = 'https://graph.facebook.com/v15.0/me/adaccounts?fields=id,account_id,business,name,adtrust_dsl,currency,account_status,balance,current_unbilled_spend,amount_spent,account_currency_ratio_to_usd,users,user_role,assigned_partners,adspaymentcycle&limit=1000&sort=name_ascending&access_token=' + token;
    let json = await reqAPI(url, 'GET')
    let obj = JSON.parse(json);
    var currency_ratio
    let objListACC = obj.data
    var objAcc = {
        status: '',
        id: 'null',
        name: '',
        balance: [],
        threshold: [],
        adtrust: [],
        spent: [],
        admin: '',
        currency: '',
        acctype: '',
        created_time: '',
        timezone_offset: '',
        timezone_name: ''
    }
    for(var acc of objListACC){
        getPayment(acc['account_id'], fbdt)
        if(('act_' + act) == acc.id){
            var currency_ratio = acc.account_currency_ratio_to_usd
           for(var info in acc){
                switch (info) {
                    case 'account_id':
                        objAcc.id = acc[info];
                        break;
                    case 'name':
                        objAcc.name = acc[info];
                        break;
                    case 'account_status':
                        let status = getStatusAcc(acc[info]);
                        objAcc.status = status;
                        break;
                    case 'adtrust_dsl':
                        let limit;
                        if (acc[info] == -1) {
                            limit = 'No limit'
                        } else {
                            limit = acc[info]
                        }
                        objAcc.adtrust.push(limit);
                        if(limit !=='No limit'){
                            num = limit/currency_ratio
                            num = num.toFixed(2)
                            objAcc.adtrust.push(num);
                        }else{
                            objAcc.adtrust.push(limit);
                        }
                        break;
                    case 'balance':
                        var num =  acc[info] * 0.01;
                        num = Math.round((num + Number.EPSILON) * 100) / 100
                        var usd = num/currency_ratio
                        usd = usd.toFixed(2)
                        objAcc.balance.push(num);
                        objAcc.balance.push(usd);
                        break;
                    case 'amount_spent':
                        var num =  acc[info] * 0.01;
                        num = Math.round((num + Number.EPSILON) * 100) / 100
                        var usd = num/currency_ratio
                        usd = Math.round((usd + Number.EPSILON) * 100) / 100
                        objAcc.spent.push(num);
                        objAcc.spent.push(usd);
                        break;
                    case 'users':
                        let numAdmin = acc[info]['data'].length;
                        objAcc.admin = numAdmin;
                        break;
                    case 'currency':
                        objAcc.currency = acc[info];
                        break;
                    default:
                        if (!acc['business']) {
                            objAcc.acctype = 'AD'
                        } else {
                            objAcc.acctype = 'BM'
                        }
                }
           }

        }
    }
    let obj_info = await getAdaccinfo(act, token)
    let objthreshold = obj_info.adspaymentcycle;
    var threshold = 0;
    if(objthreshold != undefined){
        var num =   objthreshold.data[0].threshold_amount * 0.01;
        num = Math.round((num + Number.EPSILON) * 100) / 100;
        threshold = num;
    }else{
        threshold = '-'
    }
    objAcc.threshold.push(threshold)
    if(threshold!== '-'){
        var usd = threshold/currency_ratio
        objAcc.threshold.push(usd.toFixed(2))
    }else{
        objAcc.threshold.push('-')
    }

    objAcc.created_time = obj_info.created_time.slice(0,10)
    objAcc.timezone_offset = obj_info.timezone_offset_hours_utc
    objAcc.timezone_name = obj_info.timezone_name
    return objAcc
}

async function getAdaccinfo(acc, token){
    let url = 'https://graph.facebook.com/v14.0/act_' + acc + '?fields=account_id,owner_business,created_time,next_bill_date,currency,adtrust_dsl,timezone_name,timezone_offset_hours_utc,business_country_code,disable_reason,adspaymentcycle{threshold_amount},balance,is_prepay_account,owner,all_payment_methods{pm_credit_card{display_string,exp_month,exp_year,is_verified},payment_method_direct_debits{address,can_verify,display_string,is_awaiting,is_pending,status},payment_method_paypal{email_address},payment_method_tokens{current_balance,original_balance,time_expire,type}},total_prepay_balance,insights.date_preset(maximum){spend}&access_token='+ token + '&locale=en_US'
    let json = await reqAPI(url, 'GET');
    let obj = JSON.parse(json);
    return obj
}

function getStatusAcc(num) {
    let astatus = ''
    switch (num) {
        case 1:
            astatus = 'Active';
            break; ///active
        case 2:
            astatus = 'Disable';
            break; //disabled
        case 3:
            astatus = 'Dư Nợ';
            break;
        case 7:
            astatus = "Pending Review"; //PENDING_RISK_REVIEW 
            break;
        case 8:
            astatus = "Pending Settlement";
            break;
        case 9:
            astatus = "Ân hạn"; //IN_GRACE_PERIOD In 
            break;
        case 100:
            astatus = 'Pending Closure';
            break;
        case 101:
            astatus = 'Đóng';
            break;
        case 201:
            astatus = "Any Active";
            break;
        case 202:
            astatus = "Any Close";
            break;
        default:
            astatus = "Unknow"
            break;
    }
    return astatus
}


async function getToken(act) {
    let url = 'https://business.facebook.com/adsmanager/manage/accounts?act=' + act
    let xhttp = new XMLHttpRequest();
    xhttp.open('GET', url, true)
    xhttp.setRequestHeader('Access-Control-Allow-Origin', '*');
    xhttp.setRequestHeader('Access-Control-Allow-Methods', '*');
    xhttp.setRequestHeader('Access-Control-Allow-Headers', '*');
    xhttp.setRequestHeader('Access-Control-Allow-Credentials', true);
    xhttp.send()

    xhttp.onreadystatechange = function() {
        if (xhttp.readyState == 4 && xhttp.status == 200){
            let text = xhttp.responseText
            token = text.split('window.__accessToken="')[1].split('"')[0];
        }
    }
}
