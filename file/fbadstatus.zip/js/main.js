$(window).on('load', async function (event) {
   var fbadstatus = await init()
   if (!fbadstatus) {
      var load = document.getElementById('loadspan');
      load.innerHTML = `[LỖI] Chương trình này chỉ chạy khi bạn đã đăng nhập facebook!`
      return
   }
   $('.load').delay(0).fadeOut('fast');


   /*chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
       var url = tabs[0].url
       var flag = url.indexOf('act=')
       if(flag<0){
          var btn_export = document.getElementById('btn_export')
          btn_export.style.display='none'
       }
    })*/

   if (fbadstatus.fcase == 'render') {
      let objAds = await chrome.storage.local.get(['objAds'])
      let objBM = await chrome.storage.local.get(['objBM']);
      let objFan = await chrome.storage.local.get(['objFan']);
      let objCamp = await chrome.storage.local.get(['objCamp']);
      try {
         objAds = JSON.parse(objAds.objAds)
         objBM = JSON.parse(objBM.objBM)
         objFan = JSON.parse(objFan.objFan)
         objCamp = JSON.parse(objCamp.objCamp)
      } catch (ex) {
         reload(fbadstatus.token, fbadstatus.fbdt)
      }
      renderHTML(fbadstatus.token, fbadstatus.fbdt, objAds, objBM, objFan, objCamp)
   } else {
      reload(fbadstatus.token, fbadstatus.fbdt)
   }
   local = await chrome.storage.local.get(null)
   handlerTable()
   console.log(local)
})

async function init() {
   let token = await chrome.storage.local.get(['token']); token = token.token
   let fcase = ''
   if (token == null) {
      objToken = await getToken()
      token = objToken.token
      fbdt = objToken.fbdt
      if (token == 'NO') {
         return false
      }
      fcase = 'reload'
      chrome.storage.local.set({ 'fbdt': fbdt });
      chrome.storage.local.set({ 'token': token });
      return { token: token, fcase: fcase, fbdt: fbdt }
   } else {
      let url = 'https://graph.facebook.com/v15.0/me?access_token=' + token;
      let json = await reqAPI(url, 'GET')
      let obj = JSON.parse(json);
      if ('name' in obj) {
         fcase = 'render'
         fbdt = await chrome.storage.local.get(['fbdt']); fbdt = fbdt.fbdt
         chrome.storage.local.set({ 'token': token });
         chrome.storage.local.set({ 'fbdt': fbdt });
         chrome.storage.local.set({ 'user_id': obj.id });
         return { token: token, fcase: fcase, fbdt: fbdt }
      }
      chrome.storage.local.remove('token');
      chrome.storage.local.remove('user_id');
      chrome.storage.local.remove('fbdt');
      chrome.storage.local.remove('objAds');
      chrome.storage.local.remove('objBM');
      chrome.storage.local.remove('objFan');
      chrome.storage.local.remove('objCamp');
      chrome.storage.local.remove('objPayment');
      objToken = await getToken()
      token = objToken.token
      fbdt = objToken.fbdt
      if (token == 'NO') {
         return false
      }
      fcase = 'reload'
      chrome.storage.local.set({ 'fbdt': fbdt });
      chrome.storage.local.set({ 'token': token });
      return { token: token, fcase: fcase, fbdt: fbdt }
   }

}

async function reload(token, fbdt) {
   var tbAds = document.getElementById('tb')
   var tbBM = document.getElementById('tbBM')
   var selectBM = document.getElementById('listBM');
   var tbFanPage = document.getElementById('tbFanPage')
   var tbCamp = document.getElementById('tbCamp')
   tbAds.innerHTML = ''
   tbBM.innerHTML = ''
   tbFanPage.innerHTML = ''
   tbCamp.innerHTML = ''
   selectBM.innerHTML = ''

   chrome.storage.local.remove('objAds');
   chrome.storage.local.remove('objBM');
   chrome.storage.local.remove('objFan');
   chrome.storage.local.remove('objCamp');
   getListAccInfo(token, fbdt);
   getStatusBM(token, fbdt);
   getStatusFanPage(token);
}

function renderHTML(token, fbdt, objAds, objBM, objFan, objCamp) {
   try {
      renderHtmlAcc(objAds)
      renderHtmlBM(objBM)
      renderHtmlFan(objFan)
      renderHtmlCamp(objCamp)
   }
   catch (ere) {
      reload(token, fbdt)
   }
}

document.getElementById('btnreload').addEventListener('click', async function () {
   var fbadstatus = await init()
   if (!fbadstatus) {
      var load = document.getElementById('loadspan');
      load.innerHTML = `[LỖI] Chương trình này chỉ chạy khi bạn đã đăng nhập facebook!`
      return
   }
   $('.load').delay(0).fadeOut('fast');
   reload(fbadstatus.token, fbadstatus.fbdt)
})


function clearloadData(id) {
   $(id).delay(0).fadeOut('fast');
}

var tabLinks = document.querySelectorAll(".tablinks");
var tabContent = document.querySelectorAll(".tabcontent");

tabLinks.forEach(function (el) {
   el.addEventListener("click", openTabs);
});


function openTabs(el) {
   var btn = el.currentTarget; // lắng nghe sự kiện và hiển thị các element
   var electronic = btn.dataset.electronic; // lấy giá trị trong data-electronic

   tabContent.forEach(function (el) {
      el.classList.remove("active");
   }); //lặp qua các tab content để remove class active

   tabLinks.forEach(function (el) {
      el.classList.remove("active");
   }); //lặp qua các tab links để remove class active

   document.querySelector("#" + electronic).classList.add("active");
   // trả về phần tử đầu tiên có id="" được add class active

   btn.classList.add("active");
   // các button mà chúng ta click vào sẽ được add class active
}

document.getElementById('quicklink').addEventListener('change', function () {
   window.open(this.value, '_blank')
});
document.getElementById('listBM').addEventListener('change', function () {
   var currentBM = this.value;
   renderPixel(currentBM)
});

document.getElementById('btnclose').addEventListener('click', function () {
   window.close();
})
document.getElementById('btntab').addEventListener('click', function () {
   chrome.windows.create({ 'url': 'popup.html', 'type': 'popup', height: 570, width: 850, top: 200, left: 200 }, function (window) {
   });
})


document.getElementById('btn_export').addEventListener('click', async function (e) {
   let objPayment = await chrome.storage.local.get(['objPayment'])

   if (objPayment == undefined || Object.keys(objPayment).length === 0) {
      alert('Đang tải dữ liệu vui lòng chờ',1000)
      return
   }
   let objAds = await chrome.storage.local.get(['objAds'])
   let objBM = await chrome.storage.local.get(['objBM']);
   try {
      objPayment = objPayment.objPayment
      objAds = JSON.parse(objAds.objAds)
      objBM = JSON.parse(objBM.objBM)
   } catch {
      alert('Đang tải dữ liệu vui lòng chờ',1000)
      return
   }

   for (var acc of objAds) {
      acc.s_payments = objPayment[acc.s_id]
      acc.bills = objPayment[acc.s_id + '_bills']
   }

   var arrAds = [['Trạng Thái', 'Id BM', 'Id Tk', 'Tên TK', 'Dư nợ', 'Ngưỡng', 'Limit', 'Chi tiêu', 'Admin', 'Tiền tệ', 'Loại TK', 'Bill', 'Payment']]
   var arrBM = [['Trạng Thái', 'Id Bm', 'Tên BM', 'BM level', 'Limit', 'Múi giờ', 'Ngày tạo', 'Admin ẩn']]

   for (var acc of objAds) {
      var arrContent = []
      for (var info in acc) {
         if (info.slice(0, 2) == 's_') {
            arrContent.push(acc[info])
         }
      }
      var bills = acc['bills']
      try{
         bills = bills.split('\n')[0]
      }catch{
         alert('Đang tải dữ liệu vui lòng chờ',1000)
         return
      }
      arrContent.splice(1, 0, acc['h_bm'])
      arrContent.splice(11, 0, bills)
      arrAds.push(arrContent)
   }


   for (var acc of objBM) {
      var arrContent = []
      for (var info in acc) {
         if (info != 'pixel') {
            arrContent.push(acc[info])
         }
      }
      arrBM.push(arrContent)
   }


   genareExcel(arrAds, objAds, arrBM)

})

function genareExcel(arrAds, objAds, arrBM) {
   var wb = XLSX.utils.book_new();
   wb.Props = {
      Title: "SheetJS Tutorial",
      Subject: "Xuât",
      Author: "Red Stapler",
      CreatedDate: new Date(2017, 12, 19)
   };
   wb.SheetNames.push("TKQC");
   wb.SheetNames.push("BM");
   var ws = XLSX.utils.aoa_to_sheet(arrAds);
   var stt = 2
   for (var acc of objAds) {
      for (var info in acc) {
         if (info == 'bills') {
            var bills = acc[info]
            if (bills !== '') {
               var cell = ws['L' + stt]
               if (!cell.c) ws['L' + stt].c = [];
               var comment_part = {
                  a: "Fbadstatus.com",
                  t: bills
               };

               cell.c.hidden = true;
               cell.c.push(comment_part);
            }
            break;
         }
      }
      stt++
   }
   var ws1 = XLSX.utils.aoa_to_sheet(arrBM);
   wb.Sheets["TKQC"] = ws;
   wb.Sheets["BM"] = ws1;
   var wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });

   function s2ab(s) {
      var buf = new ArrayBuffer(s.length); //convert s to arrayBuffer
      var view = new Uint8Array(buf);  //create uint8array as viewer
      for (var i = 0; i < s.length; i++) view[i] = s.charCodeAt(i) & 0xFF; //convert to octet
      return buf;
   }
   var time = new Date().toLocaleString()
   saveAs(new Blob([s2ab(wbout)], { type: "application/octet-stream" }), `Xuất TKQC${time}.xlsx`);

}

async function export_googlesheet() {
   return
   btn = document.getElementById('btn_export')
   btn.style.backgroundColor = 'brown'
   url = 'https://script.google.com/macros/s/AKfycbwcUD7kIOq6GSVd1kdzkHwA3sOr48c-_rOZ_NqVjs1AezAz9F5kss6eIzoITEnemJeQ_Q/exec'
   let objPayment = await chrome.storage.local.get(['objPayment'])

   if (objPayment == undefined || Object.keys(objPayment).length === 0) {
      alert('Chưa có dữ liệu, vui lòng truy cập hoặc tải lại trang adsmanage, bill')
      return
   }
   let objAds = await chrome.storage.local.get(['objAds'])
   let objBM = await chrome.storage.local.get(['objBM']);
   try {
      objPayment = objPayment.objPayment
      objAds = JSON.parse(objAds.objAds)
      objBM = JSON.parse(objBM.objBM)
   } catch {
      alert('Sảy ra lỗi ngoại lệ, vui lòng tắt extension và load lại dữ liệu')
      return
   }

   for (var acc of objAds) {
      acc.s_payments = objPayment[acc.s_id]
      acc.bills = objPayment[acc.s_id + '_bills']
   }
   objALL = {
      'ad': objAds,
      'bm': objBM
   }
   let formData = new FormData();
   formData.append('data', JSON.stringify(objALL));
   let response = await reqAPI(url, 'POST', {}, formData)
   return
   window.open('https://docs.google.com/spreadsheets/d/106nDGY43CmyJctxeyXUu4lF0wvIcoUJ_elZDVPwxVNw/edit#gid=0', '_blank').focus();
}

document.getElementById('btn_currency').addEventListener('click', function (e) {
   btn = document.getElementById("btn_currency")

   if (btn.style.backgroundColor == 'blue') {
      btn.style.backgroundColor = 'green'
   } else {
      btn.style.backgroundColor = 'blue'
   }

   if (btn.style.backgroundColor == 'blue') {
      document.querySelectorAll('.r').forEach(function (el) {
         el.style.display = 'none';
      });
      document.querySelectorAll('.g').forEach(function (el) {
         el.style.display = 'inline';
      });
   } else {
      document.querySelectorAll('.r').forEach(function (el) {
         el.style.display = 'inline';
      });
      document.querySelectorAll('.g').forEach(function (el) {
         el.style.display = 'none';
      });
   }

})

document.getElementById('btn_camp').addEventListener('click', function (e) {
   var main_content = document.getElementsByClassName('maincontent')[0]
   var setcamp = document.getElementsByClassName('setcamp')[0]
   main_content.style.display = "none"
   setcamp.style.display = "block"
   renderSetCamp()
   renderPage()
})

document.getElementById('btn-back').addEventListener('click', function (e) {
   var main_content = document.getElementsByClassName('maincontent')[0]
   var setcamp = document.getElementsByClassName('setcamp')[0]
   main_content.style.display = "block"
   setcamp.style.display = "none"
})

async function renderPage() {
   var selectFan = document.getElementById('page_select')
   let objFan = await chrome.storage.local.get(['objFan']);
   objFan = JSON.parse(objFan.objFan)
   var text = '<option value="none">-</option>'
   for (var fan of objFan) {
      text += `<option value="${fan.id}">${fan.name}</option>`
   }
   selectFan.innerHTML = text
}


async function renderSetCamp() {
   var table = document.getElementById('listsetcamp')
   var objAds = await chrome.storage.local.get(['objAds'])
   objAds = JSON.parse(objAds.objAds)
   var objProperty = ['s_id', 's_balance', 's_threshold', 's_adtrust', 's_spent', 's_currency']
   var result = ''
   for (var acc of objAds) {
      var text = ''
      for (var info in acc) {
         if (acc.s_status == 'Active') {
            if (objProperty.includes(info)) {
               if (info == 's_id') {
                  text += `<td><input type="checkbox" class="ids" name="${acc[info]}" value="${acc[info]}"></td><td>${acc[info]}</td>`
               } else {
                  text += `<td>${acc[info]}</td>`
               }
            }
         }
      }
      if (text != '') {
         result += `<tr class="trads noselect">${text}</tr>`
      }
   }
   table.innerHTML = result
   var arrTr = document.getElementsByClassName('trads')
   var arrIds = document.getElementsByName('ids')
   handleSelect(arrTr)
}

function handleSelect(arrTr) {
   for (var i = 0; i < arrTr.length; i++) {
      arrTr[i].addEventListener('click', function (e) {
         var rb = this.querySelector('input')
         if (rb.checked) {
            rb.checked = false
         } else {
            rb.checked = true
         }

         handler()
      })
   }
}

function handler() {
   var arrInput = document.getElementsByClassName('ids')
   var text_select = document.getElementById('text_select')
   var arrAdsAcc = []
   for (var i = 0; i < arrInput.length; i++) {
      var check = arrInput[i].checked
      if (check) {
         arrAdsAcc.push(arrInput[i].value)
      }
   }
   chrome.storage.local.set({ 'selectacc': arrAdsAcc });
   text_select.innerHTML = `Đã chọn ${arrAdsAcc.length} TK`
}


document.getElementById('selectAll').addEventListener('click', function () {
   var check = document.getElementById('selectAll')
   var arrInput = document.getElementsByClassName('ids')
   var text_select = document.getElementById('text_select')
   var arrAdsAcc = []
   if (check.checked) {
      for (var i = 0; i < arrInput.length; i++) {
         arrInput[i].checked = true
         arrAdsAcc.push(arrInput[i].value)
      }
   } else {
      for (var i = 0; i < arrInput.length; i++) {
         arrInput[i].checked = false
      }
   }

   chrome.storage.local.set({ 'selectacc': arrAdsAcc });
   text_select.innerHTML = `Đã chọn ${arrAdsAcc.length} TK`
})


document.getElementById('page_select').addEventListener('change', function () {
   var currentPage = this.value;
   console.log(currentPage)
   if (currentPage != 'none') {
      renderPost(currentPage)
   }
});

async function renderPost(page) {
   let token = await chrome.storage.local.get(['token'])
   token = token.token
   let url = `https://graph.facebook.com/v15.0/${page}/posts?fields=call_to_action,message,is_eligible_for_promotion,promotable_id,attachments.limit(10){description,description_tags,media,media_type,target,title,type,subattachments,unshimmed_url,url}&access_token=` + token;
   let json = await reqAPI(url, 'GET')
   let objJSON = JSON.parse(json);
   objJSON = objJSON.data
   for (var posts of objJSON) {
      if ('attachments' in posts) {
         console.log(posts)
      }
   }
}

window.alert = function (message, timeout = null) {
   const alert = document.createElement('div')
   const alertButton = document.createElement('button')
   alertButton.innerHTML= 'OK'
   alert.classList.add('alert')
   alert.setAttribute('style', `
   position: fixed;
   top: 180px;
   justify-content: center;
   background: #e1f4e2;
   align-items: center;
   color: inherit;
   left: 323px;
   padding: 5px 4px;
   width: 150px;
   border-radius: 5px;
   font-size: 12px;
   display: flex;
   flex-direction: column;
   border: 1px solid #5a5050;
   `
   )
   alertButton.setAttribute('style', `
   border: 1px solid #333;
   border-radius: 5px;
   width: 50%;
   background-color: #fffde2;
   `)
   alert.innerHTML = `<span style='padding: 5px'>${message}</span>`
   alertButton.addEventListener('click', (e) => {
      alert.remove()
   })
   if (timeout != null) {
      setTimeout(() => {
         alert.remove()
      }, Number(timeout))

      document.body.appendChild(alert)
   }
}

function handlerTable(){
   thall = document.querySelectorAll('#thall th')
   thall.forEach((head, i) => {

      head.onclick = () => {
         tb = document.getElementById('tball')
         var flag = head.classList.value
         thall.forEach(head => head.classList.remove('az'))
         thall.forEach(head => head.classList.remove('za'))
      thall.forEach(head => head.classList.add('sort'))
         if(flag==''){
            head.classList.add('az')
            sortTable(tb, i, false)
         }else if(flag=='az' || flag=='sort az'){
            head.classList.add('za')
            sortTable(tb, i, true)
         }else{
            head.classList.add('az')
            sortTable(tb, i, false)
         }
      }
   })

   thBMall = document.querySelectorAll('#thBMall th')
   thBMall.forEach((head, i) => {

      head.onclick = () => {
         tb = document.getElementById('tbBMall')
         var flag = head.classList.value
         thBMall.forEach(head => head.classList.remove('az'))
         thBMall.forEach(head => head.classList.remove('za'))
         if(flag==''){
            head.classList.add('az')
            sortTable(tb, i, false)
         }else if(flag=='az' || flag=='sort az'){
            head.classList.add('za')
            sortTable(tb, i, true)
         }else{
            head.classList.add('az')
            sortTable(tb, i, false)
         }
      }
   })

   thFanPageall = document.querySelectorAll('#thFanPageall th')
   thFanPageall.forEach((head, i) => {

      head.onclick = () => {
         tb = document.getElementById('tbFanPageall')
         var flag = head.classList.value
         thFanPageall.forEach(head => head.classList.remove('az'))
         thFanPageall.forEach(head => head.classList.remove('za'))
         if(flag==''){
            head.classList.add('az')
            sortTable(tb, i, false)
         }else if(flag=='az'  || flag=='sort az'){
            head.classList.add('za')
            sortTable(tb, i, true)
         }else{
            head.classList.add('az')
            sortTable(tb, i, false)
         }
      }
   })

   thCampall = document.querySelectorAll('#thCampall th')
   thCampall.forEach((head, i) => {
      head.onclick = () => {
         tb = document.getElementById('tbCampall')
         var flag = head.classList.value
         thCampall.forEach(head => head.classList.remove('az'))
         thCampall.forEach(head => head.classList.remove('za'))
         if(flag==''){
            head.classList.add('az')
            sortTable(tb, i, false)
         }else if(flag=='az'  || flag=='sort az'){
            head.classList.add('za')
            sortTable(tb, i, true)
         }else{
            head.classList.add('az')
            sortTable(tb, i, false)
         }
      }
   })

}


function sortTable(table, col, reverse) {
   var tb = table.tBodies[0],
       tr = Array.prototype.slice.call(tb.rows, 0), // put rows into array
       i;
   reverse = -((+reverse) || -1);
   tr = tr.sort(function (a, b) { 
       return reverse 
           * (a.cells[col].textContent.trim() 
               .localeCompare(b.cells[col].textContent.trim())
              );
   });
   for(i = 0; i < tr.length; ++i) tb.appendChild(tr[i]);
}
