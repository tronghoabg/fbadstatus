$(window).on('load', async function (event) {
   try {
      let token = await getToken();
      $('.load').delay(0).fadeOut('fast');
      let fbdt = await  getFbdtsg();
      main(token, fbdt)
   }
   catch (ex) {
      var load = document.getElementById('loadspan');
      load.innerHTML = `Error: The program only runs when you are logged in facebook`
      return
   }
   finally {
      // Khối lệnh này sẽ được thực thi
      // cho dù có lỗi hay không lỗi
   }

})



function clearloadData(id){
  $(id).delay(0).fadeOut('fast');
}

var tabLinks = document.querySelectorAll(".tablinks");
var tabContent = document.querySelectorAll(".tabcontent");

tabLinks.forEach(function (el) {
   el.addEventListener("click", openTabs);
});


function openTabs(el) {
   var btn = el.currentTarget; // lắng nghe sự kiện và hiển thị các element
   var electronic = btn.dataset.electronic; // lấy giá trị trong data-electronic

   tabContent.forEach(function (el) {
      el.classList.remove("active");
   }); //lặp qua các tab content để remove class active

   tabLinks.forEach(function (el) {
      el.classList.remove("active");
   }); //lặp qua các tab links để remove class active

   document.querySelector("#" + electronic).classList.add("active");
   // trả về phần tử đầu tiên có id="" được add class active

   btn.classList.add("active");
   // các button mà chúng ta click vào sẽ được add class active
}



document.getElementById('quicklink').addEventListener('change', function () {
   window.open(this.value, '_blank')
});
document.getElementById('listBM').addEventListener('change', function () {
   var currentBM = this.value;
   getListPixel(currentBM)

});

document.getElementById('btnclose').addEventListener('click', function () {
   window.close();
})
document.getElementById('btntab').addEventListener('click', function () {
   chrome.windows.create({'url': 'popup.html', 'type': 'popup', height: 500, width: 815, top: 200, left: 200}, function(window) {
   });
})
document.getElementById('btnreload').addEventListener('click', function () {
   window.location.reload()
})

document.getElementById('btn_currency').addEventListener('click', function (e) {
      btn = document.getElementById("btn_currency")
      
      if (btn.style.backgroundColor=='blue'){ 
         btn.style.backgroundColor='green'
       }else{
         btn.style.backgroundColor='blue'
       }

      if ( btn.style.backgroundColor=='blue'){  
         document.querySelectorAll('.r').forEach(function(el) {
            el.style.display = 'none';
         });
         document.querySelectorAll('.g').forEach(function(el) {
            el.style.display = 'inline';
         });
      }else{
         document.querySelectorAll('.r').forEach(function(el) {
            el.style.display = 'inline';
         });
         document.querySelectorAll('.g').forEach(function(el) {
            el.style.display = 'none';
         });
      }

})