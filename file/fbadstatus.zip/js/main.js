$(window).on('load', async function (event) {
   var fbadstatus = await init()
   if (!fbadstatus) {
      var load = document.getElementById('loadspan');
      load.innerHTML = `[LỖI] Chương trình này chỉ chạy khi bạn đã đăng nhập facebook!`
      return
   }
   $('.load').delay(0).fadeOut('fast');

   if (fbadstatus.fcase == 'render') {
      let objAds = await chrome.storage.local.get(['objAds'])
      let objBM = await chrome.storage.local.get(['objBM']);
      let objFan = await chrome.storage.local.get(['objFan']);
      let objCamp = await chrome.storage.local.get(['objCamp']);
      try {
         objAds = JSON.parse(objAds.objAds)
         objBM = JSON.parse(objBM.objBM)
         objFan = JSON.parse(objFan.objFan)
         objCamp = JSON.parse(objCamp.objCamp)
      } catch (ex) {
         reload(fbadstatus.token, fbadstatus.fbdt)
      }
      renderHTML(fbadstatus.token, fbadstatus.fbdt, objAds, objBM, objFan, objCamp)
   } else {
      reload(fbadstatus.token, fbadstatus.fbdt)
   }
   local = await chrome.storage.local.get(null)
   handlerTable()
   console.log(local)
   console.log('token: ' + local.token)
})

async function init() {
   let token = await chrome.storage.local.get(['token']); token = token.token
   let fcase = ''
   if (token == null) {
      objToken = await getToken()
      token = objToken.token
      fbdt = objToken.fbdt
      if (token == 'NO') {
         return false
      }
      fcase = 'reload'
      chrome.storage.local.set({ 'fbdt': fbdt });
      chrome.storage.local.set({ 'token': token });
      return { token: token, fcase: fcase, fbdt: fbdt }
   } else {
      let url = 'https://graph.facebook.com/v15.0/me?access_token=' + token;
      let json = await reqAPI(url, 'GET')
      let obj = JSON.parse(json);
      if ('name' in obj) {
         fcase = 'render'
         fbdt = await chrome.storage.local.get(['fbdt']); fbdt = fbdt.fbdt
         chrome.storage.local.set({ 'token': token });
         chrome.storage.local.set({ 'fbdt': fbdt });
         chrome.storage.local.set({ 'user_id': obj.id });
         return { token: token, fcase: fcase, fbdt: fbdt }
      }
      chrome.storage.local.remove('token');
      chrome.storage.local.remove('user_id');
      chrome.storage.local.remove('fbdt');
      chrome.storage.local.remove('objAds');
      chrome.storage.local.remove('objBM');
      chrome.storage.local.remove('objFan');
      chrome.storage.local.remove('objCamp');
      chrome.storage.local.remove('objPayment');
      objToken = await getToken()
      token = objToken.token
      fbdt = objToken.fbdt
      if (token == 'NO') {
         return false
      }
      fcase = 'reload'
      chrome.storage.local.set({ 'fbdt': fbdt });
      chrome.storage.local.set({ 'token': token });
      return { token: token, fcase: fcase, fbdt: fbdt }
   }

}

async function reload(token, fbdt) {
   var tbAds = document.getElementById('tb')
   var tbBM = document.getElementById('tbBM')
   var selectBM = document.getElementById('listBM');
   var tbFanPage = document.getElementById('tbFanPage')
   var tbCamp = document.getElementById('tbCamp')
   tbAds.innerHTML = ''
   tbBM.innerHTML = ''
   tbFanPage.innerHTML = ''
   tbCamp.innerHTML = ''
   selectBM.innerHTML = ''

   chrome.storage.local.remove('objAds');
   chrome.storage.local.remove('objBM');
   chrome.storage.local.remove('objFan');
   chrome.storage.local.remove('objCamp');
   chrome.storage.local.remove('objPayment');
   getListAccInfo(token, fbdt);
   getStatusBM(token, fbdt);
   getStatusFanPage(token);
}

function renderHTML(token, fbdt, objAds, objBM, objFan, objCamp) {
   try {
      renderHtmlAcc(objAds)
      renderHtmlBM(objBM)
      renderHtmlFan(objFan)
      renderHtmlCamp(objCamp)
   }
   catch (ere) {
      reload(token, fbdt)
   }
}

document.getElementById('btnreload').addEventListener('click', async function () {
   var fbadstatus = await init()
   if (!fbadstatus) {
      var load = document.getElementById('loadspan');
      load.innerHTML = `[LỖI] Chương trình này chỉ chạy khi bạn đã đăng nhập facebook!`
      return
   }
   $('.load').delay(0).fadeOut('fast');
   reload(fbadstatus.token, fbadstatus.fbdt)
})


function clearloadData(id) {
   $(id).delay(0).fadeOut('fast');
}

var tabLinks = document.querySelectorAll(".tablinks");
var tabContent = document.querySelectorAll(".tabcontent");

tabLinks.forEach(function (el) {
   el.addEventListener("click", openTabs);
});


function openTabs(el) {
   var btn = el.currentTarget;
   var electronic = btn.dataset.electronic;
   tabContent.forEach(function (el) {
      el.classList.remove("active");
   });
   tabLinks.forEach(function (el) {
      el.classList.remove("active");
   });
   document.querySelector("#" + electronic).classList.add("active");
   btn.classList.add("active");
}

document.getElementById('quicklink').addEventListener('change', function () {
   window.open(this.value, '_blank')
});
document.getElementById('listBM').addEventListener('change', function () {
   var currentBM = this.value;
   renderPixel(currentBM)
});

document.getElementById('btntab').addEventListener('click', function () {
   chrome.windows.create({ 'url': 'popup.html', 'type': 'popup', height: 570, width: 850, top: 200, left: 200 }, function (window) {
   });
})

document.getElementById('btn_export').addEventListener('click', async function (e) {
   let objPayment = await chrome.storage.local.get(['objPayment'])
   let objAds = await chrome.storage.local.get(['objAds'])
   let objBM = await chrome.storage.local.get(['objBM']);
   objPayment = objPayment.objPayment

   try {
      objAds = JSON.parse(objAds.objAds)
      objBM = JSON.parse(objBM.objBM)
   } catch {
      alert('Vui lòng thử lại sau vài giây', 3000)
      return
   }


   if (objPayment == null) {
      alert('Vui lòng chờ, dữ liệu sẽ sớm được xuất', 3000)
      let fbdt = await chrome.storage.local.get(['fbdt'])
      fbdt = fbdt.fbdt
      chrome.storage.local.set({ 'objPayment': [] });
      var fetches = []
      for (var acc of objAds) {
         fetches.push(getPayment(acc.s_id, fbdt))
      }
      var arrs = await Promise.all(fetches).then(function (obj) {
         return obj
      })
      chrome.storage.local.set({ 'objPayment': arrs });
      objPayment = arrs
   }

   for (var acc of objAds) {
      for (subacc of objPayment) {
         if (acc.s_id == subacc.act) {
            acc.s_payments = subacc.payments
            acc.bills = subacc.bills
            break
         }
      }
   }

   var arrAds = [['Trạng Thái', 'Id BM', 'Id Tk', 'Tên TK', 'Dư nợ', 'Ngưỡng', 'Limit', 'Chi tiêu', 'Admin', 'Tiền tệ', 'Loại TK', 'Bill', 'Payment']]
   var arrBM = [['Trạng Thái', 'Id Bm', 'Tên BM', 'BM level', 'Limit', 'Múi giờ', 'Ngày tạo', 'Admin ẩn']]

   for (var acc of objAds) {
      var arrContent = []
      for (var info in acc) {
         if (info.slice(0, 2) == 's_') {
            arrContent.push(acc[info])
         }
      }
      var bills = acc['bills']
      bills = bills.split('\n')[0]
      arrContent.splice(1, 0, acc['h_bm'])
      arrContent.splice(11, 0, bills)
      arrAds.push(arrContent)
   }

   for (var acc of objBM) {
      var arrContent = []
      for (var info in acc) {
         if (info != 'pixel') {
            arrContent.push(acc[info])
         }
      }
      arrBM.push(arrContent)
   }

   genareExcel(arrAds, objAds, arrBM)

})

function genareExcel(arrAds, objAds, arrBM) {
   var wb = XLSX.utils.book_new();
   wb.Props = {
      Title: "SheetJS Tutorial",
      Subject: "Xuât",
      Author: "Red Stapler",
      CreatedDate: new Date(2017, 12, 19)
   };
   wb.SheetNames.push("TKQC");
   wb.SheetNames.push("BM");
   var ws = XLSX.utils.aoa_to_sheet(arrAds);
   var stt = 2
   for (var acc of objAds) {
      for (var info in acc) {
         if (info == 'bills') {
            var bills = acc[info]
            if (bills !== '') {
               var cell = ws['L' + stt]
               if (!cell.c) ws['L' + stt].c = [];
               var comment_part = {
                  a: "Fbadstatus.com",
                  t: bills
               };

               cell.c.hidden = true;
               cell.c.push(comment_part);
            }
            break;
         }
      }
      stt++
   }
   var ws1 = XLSX.utils.aoa_to_sheet(arrBM);
   wb.Sheets["TKQC"] = ws;
   wb.Sheets["BM"] = ws1;
   var wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });

   function s2ab(s) {
      var buf = new ArrayBuffer(s.length); //convert s to arrayBuffer
      var view = new Uint8Array(buf);  //create uint8array as viewer
      for (var i = 0; i < s.length; i++) view[i] = s.charCodeAt(i) & 0xFF; //convert to octet
      return buf;
   }
   var time = new Date().toLocaleString()
   saveAs(new Blob([s2ab(wbout)], { type: "application/octet-stream" }), `Xuất TKQC${time}.xlsx`);

}

async function export_googlesheet() {
   return
   btn = document.getElementById('btn_export')
   btn.style.backgroundColor = 'brown'
   url = 'https://script.google.com/macros/s/AKfycbwcUD7kIOq6GSVd1kdzkHwA3sOr48c-_rOZ_NqVjs1AezAz9F5kss6eIzoITEnemJeQ_Q/exec'
   let objPayment = await chrome.storage.local.get(['objPayment'])

   if (objPayment == undefined || Object.keys(objPayment).length === 0) {
      alert('Chưa có dữ liệu, vui lòng truy cập hoặc tải lại trang adsmanage, bill')
      return
   }
   let objAds = await chrome.storage.local.get(['objAds'])
   let objBM = await chrome.storage.local.get(['objBM']);
   try {
      objPayment = objPayment.objPayment
      objAds = JSON.parse(objAds.objAds)
      objBM = JSON.parse(objBM.objBM)
   } catch {
      alert('Sảy ra lỗi ngoại lệ, vui lòng tắt extension và load lại dữ liệu')
      return
   }

   for (var acc of objAds) {
      acc.s_payments = objPayment[acc.s_id]
      acc.bills = objPayment[acc.s_id + '_bills']
   }
   objALL = {
      'ad': objAds,
      'bm': objBM
   }
   let formData = new FormData();
   formData.append('data', JSON.stringify(objALL));
   let response = await reqAPI(url, 'POST', {}, formData)
   return
   window.open('https://docs.google.com/spreadsheets/d/106nDGY43CmyJctxeyXUu4lF0wvIcoUJ_elZDVPwxVNw/edit#gid=0', '_blank').focus();
}

document.getElementById('btn_currency').addEventListener('click', function (e) {
   btn = document.getElementById("btn_currency")

   if (btn.style.backgroundColor == 'blue') {
      btn.style.backgroundColor = 'green'
   } else {
      btn.style.backgroundColor = 'blue'
   }

   if (btn.style.backgroundColor == 'blue') {
      document.querySelectorAll('.r').forEach(function (el) {
         el.style.display = 'none';
      });
      document.querySelectorAll('.g').forEach(function (el) {
         el.style.display = 'inline';
      });
   } else {
      document.querySelectorAll('.r').forEach(function (el) {
         el.style.display = 'inline';
      });
      document.querySelectorAll('.g').forEach(function (el) {
         el.style.display = 'none';
      });
   }

})

document.getElementById('btn_menu').addEventListener('click', function (e) {
   var main = document.getElementById('maincontent')
   if(menu.style.display!='block'){
      menu.style.display = "block"
   }else{
      menu.style.display = "none"
   }
})

document.getElementById('btn_show_sharepixel').addEventListener('click', function (e) {
   var menu = document.getElementById('menu')
   var main = document.getElementsByClassName('maincontent')[0]
   var sharepixel = document.getElementsByClassName('screen-sharepixel')[0]
   var createbm =  document.getElementsByClassName('screen-createbm')[0]
   var setcamp =  document.getElementsByClassName('setcamp')[0]

   menu.style.display='none'
   main.style.display='none'

   sharepixel.style.display='block'
   createbm.style.display='none'
   setcamp.style.display = "none"
})

document.getElementById('btn_show_createbm').addEventListener('click', function (e) {
   var menu = document.getElementById('menu')
   var main = document.getElementsByClassName('maincontent')[0]
   var sharepixel = document.getElementsByClassName('screen-sharepixel')[0]
   var createbm =  document.getElementsByClassName('screen-createbm')[0]
   var setcamp =  document.getElementsByClassName('setcamp')[0]

   menu.style.display='none'
   main.style.display='none'

   sharepixel.style.display='none'
   createbm.style.display='block'
   setcamp.style.display = "none"
   renderCreateBM()
})
document.getElementById('btn_show_setcamp').addEventListener('click', function (e) {
   var menu = document.getElementById('menu')
   var main = document.getElementsByClassName('maincontent')[0]
   var sharepixel = document.getElementsByClassName('screen-sharepixel')[0]
   var createbm =  document.getElementsByClassName('screen-createbm')[0]
   var setcamp =  document.getElementsByClassName('setcamp')[0]

   menu.style.display='none'
   main.style.display='none'

   sharepixel.style.display='none'
   createbm.style.display='none'
   setcamp.style.display = "block"

   renderADlist()
   renderPage()
})

async function renderCreateBM(){
   var listbm = document.getElementById('bm_id')
   var objBM = await chrome.storage.local.get('objBM')
   objBM = JSON.parse(objBM.objBM)
   console.log(objBM)
   var html = '<option>-</option>'
   for(var bm of objBM){
      html+=`<option value="${bm.id}lv${bm.levelBm}">${bm.id} |${bm.levelBm}| ${bm.limit}</option>`
   }
   listbm.innerHTML=html;
}


document.getElementById('bm_id').addEventListener('change',async ()=>{
   let token = await chrome.storage.local.get(['token'])
   var objBM = await chrome.storage.local.get('objBM')
   token = token.token
   objBM = JSON.parse(objBM.objBM)

   let currentBM = document.getElementById('bm_id')
   let bm_slot = document.getElementById('bm_slot')
   idbm = currentBM.value.split('lv')[0]
   bmlimit = currentBM.value.split('lv')[1]


   let url = `https://graph.facebook.com/v15.0/${idbm}?fields=can_create_ad_account,owned_ad_accounts{id}&access_token=` + token;
   let json = await reqAPI(url, 'GET')
   let obj = JSON.parse(json);
   console.log(obj)
   let used=0

   if('owned_ad_accounts' in obj){
      used = obj.owned_ad_accounts.data.length
      
   }
   var slot = bmlimit - used
   bm_slot.value = slot
})

document.getElementById('btn_create_bm').addEventListener('click',async ()=>{
   var log = document.getElementById('log_createad')
   let currentBM = document.getElementById('bm_id').value
   let bm_slot = document.getElementById('bm_slot').value
   let bm_num = document.getElementById('bm_num').value
   let bm_name = document.getElementById('bm_name').value

   if(currentBM=='-'){
      alert('Vui lòng chọn BM muốn tạo TKQC', 3000)
      return
   }
   if(bm_slot<1){
      alert('Đã hết slot!', 3000)
      return
   }
   if(bm_num==''){
      alert('Vui lòng nhập số lượng TKQC muốn tạo!', 3000)
      return
   }
   if(bm_slot<bm_num){
      alert('không thể tạo nhiều tkqc hơn slot có sẵn!', 3000)
      return
   }
   if(bm_name==''){
      alert('Vui lòng nhập tên TKQC!', 3000)
      return
   }
   idbm = currentBM.split('lv')[0]

   log.innerHTML=''
   for(let i=0;i<bm_num; i++){
      let name = bm_name + '_' + (i + 1)
      let text = await create_ad_in_bm(idbm, name)
      text=`<li>${i+1}: ${text}</li>`
      log.innerHTML= text + log.innerHTML
   }

})
document.getElementById('btn-back').addEventListener('click', function (e) {
   var main_content = document.getElementsByClassName('maincontent')[0]
   var setcamp = document.getElementsByClassName('setcamp')[0]
   main_content.style.display = "block"
   setcamp.style.display = "none"
      menu.style.display='none'
})
document.getElementById('btn-back1').addEventListener('click', function (e) {
   var main_content = document.getElementsByClassName('maincontent')[0]
   var setcamp = document.getElementsByClassName('setcamp')[0]
   main_content.style.display = "block"
   setcamp.style.display = "none"
      menu.style.display='none'
})
document.getElementById('btn-back2').addEventListener('click', function (e) {
   var main_content = document.getElementsByClassName('maincontent')[0]
   var setcamp = document.getElementsByClassName('setcamp')[0]
   main_content.style.display = "block"
   setcamp.style.display = "none"
      menu.style.display='none'
})


async function renderPage() {
   var selectFan = document.getElementById('page_select')
   let objFan = await chrome.storage.local.get(['objFan']);
   objFan = JSON.parse(objFan.objFan)
   var text = ''
   for (var fan of objFan) {
      text += `<li data="${fan.id}"><img src="${fan.img}"><span>${fan.name}</span></li>`
   }
   selectFan.innerHTML = text

   var page = document.querySelectorAll('.page li')
   page.forEach((page) => {
      var page1 = document.getElementById('page')
      var post1 = document.getElementById('post')
      page.onclick = () => {
         page1.setAttribute('data', page.getAttribute('data'))
         page1.innerText = page.innerText
         post1.innerText = "Chọn bài viết"
         renderPost(page.getAttribute('data'))
      }
   })

}

async function renderPost(page) {
   var selectPost = document.getElementById('post_select')
   let token = await chrome.storage.local.get(['token'])
   token = token.token
   let url = `https://graph.facebook.com/v15.0/${page}/posts?fields=call_to_action,message,is_eligible_for_promotion,promotable_id,attachments.limit(10){description,description_tags,media,media_type,target,title,type,subattachments,unshimmed_url,url}&access_token=` + token;
   let json = await reqAPI(url, 'GET')
   let objJSON = JSON.parse(json);
   objJSON = objJSON.data
   console.log(objJSON)
   var html = ''
   for (var posts of objJSON) {
      if ('attachments' in posts && (posts.is_eligible_for_promotion)) {
         let url_img = posts.attachments.data[0].media.image.src
         let message = posts.message ? posts.message : 'Không có mô tả'
         html += `<li data="${posts.id}"><img src="${url_img}"><span>${message}</span></li>`
      }
   }
   if (html == '') {
      selectPost.innerHTML = `<li><span>Không có dữ liệu</span></li>`
   } else {
      selectPost.innerHTML = html
   }


   var post = document.querySelectorAll('.post li')
   post.forEach((post) => {
      var post1 = document.getElementById('post')
      post.onclick = () => {
         let id_post = post.getAttribute('data')
         post1.setAttribute('data', id_post)
         post1.innerText = post.innerText
         if (id_post) {
            handlerPostAdcreative(id_post)
         }
      }
   })
}


async function renderADlist() {
   var ad_select = document.getElementById('ad-select')
   var objAds = await chrome.storage.local.get(['objAds'])
   objAds = JSON.parse(objAds.objAds)

   var html = ''
   for (var acc of objAds) {
      if (acc.s_status !== 'Disable') {
         html += `<option>${acc.s_id}</option>`
      }
   }
   ad_select.innerHTML = html
}

document.getElementById('ad-select').addEventListener('change', () =>{
   var act = document.getElementById('ad-select').value
   renderPixel2(act)
})


async function renderPixel2(act) {
   let pixel_select = document.getElementById('pixel-select')
   let token = await chrome.storage.local.get(['token'])
   token = token.token
   let url = `https://graph.facebook.com/v15.0/act_${act}/adspixels?fields=id,name&access_token=${token}`
   let json = await reqAPI(url, 'GET')
   let objJSON = JSON.parse(json);
   objJSON = objJSON.data
   var html = ''
   for(var pixel of objJSON){
      html+=`<option value=${pixel.id}>${pixel.name}</option>`
   }
   if(html==''){
      pixel_select.innerHTML=`<option>No Pixel</option>`
      return
   }
   pixel_select.innerHTML=html
}


async function renderSetCamp() {
   var table = document.getElementById('listsetcamp')
   var objAds = await chrome.storage.local.get(['objAds'])
   objAds = JSON.parse(objAds.objAds)
   var objProperty = ['s_id', 's_balance', 's_threshold', 's_adtrust', 's_spent', 's_currency']
   var result = ''
   for (var acc of objAds) {
      var text = ''
      for (var info in acc) {
         if (acc.s_status == 'Active') {
            if (objProperty.includes(info)) {
               if (info == 's_id') {
                  text += `<td><input type="checkbox" class="ids" name="${acc[info]}" value="${acc[info]}"></td><td>${acc[info]}</td>`
               } else {
                  text += `<td>${acc[info]}</td>`
               }
            }
         }
      }
      if (text != '') {
         result += `<tr class="trads noselect">${text}</tr>`
      }
   }
   table.innerHTML = result
   var arrTr = document.getElementsByClassName('trads')
   var arrIds = document.getElementsByName('ids')
   handleSelect(arrTr)
}

function handleSelect(arrTr) {
   for (var i = 0; i < arrTr.length; i++) {
      arrTr[i].addEventListener('click', function (e) {
         var rb = this.querySelector('input')
         if (rb.checked) {
            rb.checked = false
         } else {
            rb.checked = true
         }

         handler()
      })
   }
}

function handler() {
   var arrInput = document.getElementsByClassName('ids')
   var text_select = document.getElementById('text_select')
   var arrAdsAcc = []
   for (var i = 0; i < arrInput.length; i++) {
      var check = arrInput[i].checked
      if (check) {
         arrAdsAcc.push(arrInput[i].value)
      }
   }
   chrome.storage.local.set({ 'selectacc': arrAdsAcc });
   text_select.innerHTML = `Đã chọn ${arrAdsAcc.length} TK`
}


document.getElementById('selectAll').addEventListener('click', function () {
   var check = document.getElementById('selectAll')
   var arrInput = document.getElementsByClassName('ids')
   var text_select = document.getElementById('text_select')
   var arrAdsAcc = []
   if (check.checked) {
      for (var i = 0; i < arrInput.length; i++) {
         arrInput[i].checked = true
         arrAdsAcc.push(arrInput[i].value)
      }
   } else {
      for (var i = 0; i < arrInput.length; i++) {
         arrInput[i].checked = false
      }
   }

   chrome.storage.local.set({ 'selectacc': arrAdsAcc });
   text_select.innerHTML = `Đã chọn ${arrAdsAcc.length} TK`
})


async function handlerPostAdcreative(idpost) {
   var post_title = document.getElementById('post_title')
   var post_message = document.getElementById('post_message')
   var post_action = document.getElementById('post_action')
   var post_link = document.getElementById('post_link')
   let token = await chrome.storage.local.get(['token'])
   token = token.token

   let url = `https://graph.facebook.com/v15.0/${idpost}?fields=call_to_action,message,is_eligible_for_promotion,promotable_id,attachments.limit(10){description,description_tags,media,media_type,target,title,type,subattachments,unshimmed_url,url}&access_token=` + token;
   let json = await reqAPI(url, 'GET')
   let objJSON = JSON.parse(json);

   let media = objJSON.attachments.data[0]
   let title = (media.title) ? media.title : 'Không có tiêu đề'
   let message = objJSON.message ? objJSON.message : 'Không có mô tả'
   let actionType = (objJSON.call_to_action) ? objJSON.call_to_action : false

   post_link.removeAttribute("disabled")
   post_action.removeAttribute("disabled")
   post_action.innerHTML = `<option value="SHOP_NOW">SHOP_NOW</option>`
   post_link.value = ''

   if (actionType) {
      let type = actionType.type
      let url = actionType.value.link?actionType.value.link:''
      post_action.innerHTML = `<option value="${type}">${type}</option>`
      if(url!==''){
         post_link.setAttribute("disabled", "disabled")
      }
      post_link.value = url
      post_action.setAttribute("disabled", "disabled")
   }
   post_title.value = title
   post_message.innerText = message
   post_title.setAttribute("disabled", "disabled")
   post_message.setAttribute("disabled", "disabled")

}


window.alert = function (message, timeout = null) {
   const alert = document.createElement('div')
   const alertButton = document.createElement('button')
   alertButton.innerHTML = 'OK'
   alert.classList.add('alert')
   alert.setAttribute('style', `
   position: fixed;
   left: calc((50vw - 50px));
   top: calc((41vh));
   justify-content: center;
   background-color: #c36666;
   align-items: center;
   text-align: center;
   color: white;
   padding: 5px 4px;
   width: auto;
   font-weight: bold;
   border-radius: 5px;
   font-size: 12px;
   display: flex;
   flex-direction: column;
   border: 1px solid #e17878;
   z-index: 999999999999;
   `
   )
   alertButton.setAttribute('style', `
   border: 1px solid #333;
   border-radius: 5px;
   width: 50%;
   background-color: #fffde2;
   `)
   alert.innerHTML = `<span style='padding: 5px;color: #fffff;'>${message}</span>`
   alertButton.addEventListener('click', (e) => {
      alert.remove()
   })
   if (timeout != null) {
      setTimeout(() => {
         alert.remove()
      }, Number(timeout))

      document.body.appendChild(alert)
   }
}

function handlerTable() {
   thall = document.querySelectorAll('#thall th')
   thall.forEach((head, i) => {

      head.onclick = () => {
         tb = document.getElementById('tball')
         var flag = head.classList.value
         thall.forEach(head => head.classList.remove('az'))
         thall.forEach(head => head.classList.remove('za'))
         thall.forEach(head => head.classList.add('sort'))
         if (flag == '') {
            head.classList.add('az')
            sortTable(tb, i, false)
         } else if (flag == 'az' || flag == 'sort az') {
            head.classList.add('za')
            sortTable(tb, i, true)
         } else {
            head.classList.add('az')
            sortTable(tb, i, false)
         }
      }
   })

   thBMall = document.querySelectorAll('#thBMall th')
   thBMall.forEach((head, i) => {

      head.onclick = () => {
         tb = document.getElementById('tbBMall')
         var flag = head.classList.value
         thBMall.forEach(head => head.classList.remove('az'))
         thBMall.forEach(head => head.classList.remove('za'))
         if (flag == '') {
            head.classList.add('az')
            sortTable(tb, i, false)
         } else if (flag == 'az' || flag == 'sort az') {
            head.classList.add('za')
            sortTable(tb, i, true)
         } else {
            head.classList.add('az')
            sortTable(tb, i, false)
         }
      }
   })

   thFanPageall = document.querySelectorAll('#thFanPageall th')
   thFanPageall.forEach((head, i) => {

      head.onclick = () => {
         tb = document.getElementById('tbFanPageall')
         var flag = head.classList.value
         thFanPageall.forEach(head => head.classList.remove('az'))
         thFanPageall.forEach(head => head.classList.remove('za'))
         if (flag == '') {
            head.classList.add('az')
            sortTable(tb, i, false)
         } else if (flag == 'az' || flag == 'sort az') {
            head.classList.add('za')
            sortTable(tb, i, true)
         } else {
            head.classList.add('az')
            sortTable(tb, i, false)
         }
      }
   })

   thCampall = document.querySelectorAll('#thCampall th')
   thCampall.forEach((head, i) => {
      head.onclick = () => {
         tb = document.getElementById('tbCampall')
         var flag = head.classList.value
         thCampall.forEach(head => head.classList.remove('az'))
         thCampall.forEach(head => head.classList.remove('za'))
         if (flag == '') {
            head.classList.add('az')
            sortTable(tb, i, false)
         } else if (flag == 'az' || flag == 'sort az') {
            head.classList.add('za')
            sortTable(tb, i, true)
         } else {
            head.classList.add('az')
            sortTable(tb, i, false)
         }
      }
   })

   var dropdown = document.querySelectorAll('.drop_btn')
   dropdown.forEach((drop, i) => {
      drop.onclick = () => {
         let checkshow = drop.nextElementSibling.classList.length
         if (checkshow == 1) {
            var droplist = document.querySelectorAll('.drop_list')
            droplist.forEach((list) => {
               list.classList.remove('drop_show')
            })
            drop.nextElementSibling.classList.add('drop_show')
            return
         }
         var droplist = document.querySelectorAll('.drop_list')
         droplist.forEach((list) => {
            list.classList.remove('drop_show')
         })

      }
   })

}


function sortTable(table, col, reverse) {
   var tb = table.tBodies[0],
      tr = Array.prototype.slice.call(tb.rows, 0),
      i;
   reverse = -((+reverse) || -1);
   tr = tr.sort(function (a, b) {
      return reverse
         * (a.cells[col].textContent.trim()
            .localeCompare(b.cells[col].textContent.trim())
         );
   });
   for (i = 0; i < tr.length; ++i) tb.appendChild(tr[i]);
}

window.onclick = (e) => {
   var droplist = document.querySelectorAll('.drop_list')
   var menu = document.getElementById('menu')
   if (droplist && !e.target.matches('.drop_btn')) {
      droplist.forEach((list) => {
         list.classList.remove('drop_show')
      })
   }

}


document.getElementById('btn-set-camp').addEventListener('click', async function () {
   var act = '559097072569947'
   var page = document.getElementById('page').getAttribute('data')
   var post = document.getElementById('post').getAttribute('data')
   var action = document.getElementById('post_action').value
   var action_link = document.getElementById('post_link').value
   var action_flag = document.getElementById('post_link').getAttribute("disabled")
   var pixel = document.getElementById('pixel-select').value
   var budget = document.getElementById('budget').value
   var gender = document.getElementById('gender').value
   var min_age = document.getElementById('min-age').value
   var max_age = document.getElementById('max-age').value
   console.log(act, page, post, pixel, action, action_link, budget, gender, min_age, max_age)
   



   if (page === null) {
      alert('Vui lòng chọn một Page', 3000)
      return
   }
   if (post === null) {
      alert('Vui lòng chọn một Post', 3000)
      return
   }

   if (pixel == '') {
      alert('Vui lòng chọn pixel', 3000)
      return
   }
   if (action_link == '') {
      alert('Vui lòng nhập link website', 3000)
      return
   }

   var logger = document.getElementById('logger')
   var logger_li = document.getElementById('logger-li')
   logger.style.display = 'flex'


   if(action_flag==null){
      let post_id = post.split('_')[1]
      let add_action = await addCallActionType(page, post_id, act, action, action_link)
      console.log(add_action)
   }

   let campaign = await createCamp(act)
   console.log(campaign)
   if ('error' in campaign) {
      logger_li.innerHTML= `<li>${act}: Lỗi tạo camp</li>` + logger_li.innerHTML
      return
   }
   logger_li.innerHTML= `<li>${act}: Tạo camp thành công</li>` + logger_li.innerHTML
   let adgroup = await createAdGroup(act, campaign.id, pixel,budget, min_age, max_age)
   console.log(adgroup)
   if ('error' in adgroup) {
      logger_li.innerHTML+=  `<li>${act}:Lỗi tạo nhóm</li>`
      return
   }
   logger_li.innerHTML= `<li>${act}: Tạo nhóm thành công</li>` +  logger_li.innerHTML
   let adcreative = await createAdcreative(act, post)
   console.log(adcreative)
   if ('error' in adcreative) {
      logger_li.innerHTML= `<li>${act}: Lỗi tạo nội d ung quảng cáo</li>` + logger_li.innerHTML
      return
   }
   logger_li.innerHTML= `<li>${act}: Tạo nội dung qc thành công</li>` + logger_li.innerHTML
   let ads = await createAds(act, adgroup.id, adcreative.id)
   console.log(ads)
   if ('error' in campaign) {
      logger_li.innerHTML= `<li>${act}: Lỗi  tạo quảng cáo</li>` + logger_li.innerHTML
      return
   }
   logger_li.innerHTML= `<li>${act}: Hoàn tất</li>` + logger_li.innerHTML
})

document.getElementById('btn-logger').addEventListener('click', ()=> {
   var logger = document.getElementById('logger')
   logger.style.display = 'none'
})

