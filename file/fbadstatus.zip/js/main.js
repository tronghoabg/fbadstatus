$(window).on('load', async function (event) {
   local = await chrome.storage.local.get(null)
   console.log(local)
   var fbadstatus = await init()
   if (!fbadstatus){
      var load = document.getElementById('loadspan');
      load.innerHTML = `[LỖI] Chương trình này chỉ chạy khi bạn đã đăng nhập facebook!`
      return
   }
   $('.load').delay(0).fadeOut('fast');


  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      var url = tabs[0].url
      var flag = url.indexOf('act=')
      if(flag<0){
         var btn_export = document.getElementById('btn_export')
         btn_export.style.display='none'
      }
   })

   if(fbadstatus.fcase=='render'){
      let objAds = await chrome.storage.local.get(['objAds'])
      let objBM = await chrome.storage.local.get(['objBM']);
      let objFan = await chrome.storage.local.get(['objFan']);
      let objCamp = await chrome.storage.local.get(['objCamp']);
      try{
         objAds = JSON.parse(objAds.objAds)
         objBM = JSON.parse(objBM.objBM)
         objFan = JSON.parse(objFan.objFan)
         objCamp = JSON.parse(objCamp.objCamp)
      }catch(ex){
         reload(fbadstatus.token, fbadstatus.fbdt)
      }
      renderHTML(fbadstatus.token, fbadstatus.fbdt, objAds, objBM, objFan, objCamp)
   }else{
      reload(fbadstatus.token, fbadstatus.fbdt)
   }
})

async function init(){
   let token = await chrome.storage.local.get(['token']);token = token.token
   let fcase = ''
   if(token==null){
      token = await getToken()
      if(token=='NO'){
         return false
      }
      fcase = 'reload'
      fbdt = await getFbdtsg()
      chrome.storage.local.set({ 'fbdt': fbdt });
      chrome.storage.local.set({ 'token': token });
      return {token: token, fcase: fcase, fbdt: fbdt}
   }else{
      let url = 'https://graph.facebook.com/v15.0/me?access_token=' + token;
      let json = await reqAPI(url, 'GET')
      let obj = JSON.parse(json);
      if('name' in obj){
         fcase = 'render'
         fbdt = await chrome.storage.local.get(['fbdt']);fbdt = fbdt.fbdt
         chrome.storage.local.set({ 'token': token });
         chrome.storage.local.set({ 'fbdt': fbdt });
         chrome.storage.local.set({ 'user_id': obj.id });
         return {token: token, fcase: fcase, fbdt: fbdt}
      }
      chrome.storage.local.remove('token');
      chrome.storage.local.remove('user_id');
      chrome.storage.local.remove('fbdt');
      chrome.storage.local.remove('objAds');
      chrome.storage.local.remove('objBM');
      chrome.storage.local.remove('objFan');
      chrome.storage.local.remove('objCamp');
      chrome.storage.local.remove('objPayment');
      token = await getToken()
      if(token=='NO'){
         return false
      }
      fcase = 'reload'
      fbdt = await getFbdtsg()
      chrome.storage.local.set({ 'fbdt': fbdt });
      chrome.storage.local.set({ 'token': token });
      return {token: token, fcase: fcase, fbdt: fbdt}
   }
}

async function reload(token, fbdt){
   var tbAds = document.getElementById('tb')
   var tbBM = document.getElementById('tbBM')
   var selectBM = document.getElementById('listBM');
   var tbFanPage = document.getElementById('tbFanPage')
   var tbCamp = document.getElementById('tbCamp')
   tbAds.innerHTML = ''
   tbBM.innerHTML = ''
   tbFanPage.innerHTML = ''
   tbCamp.innerHTML = ''
   selectBM.innerHTML= ''

   chrome.storage.local.remove('objAds');
   chrome.storage.local.remove('objBM');
   chrome.storage.local.remove('objFan');
   chrome.storage.local.remove('objCamp');
   getListAccInfo(token, fbdt);
   getStatusBM(token, fbdt);
   getStatusFanPage(token);
}

function renderHTML(token, fbdt, objAds, objBM, objFan, objCamp){
   try{
      renderHtmlAcc(objAds)
      renderHtmlBM(objBM)
      renderHtmlFan(objFan)
      renderHtmlCamp(objCamp)
   }
   catch(ere){
      reload(token, fbdt)
   }
}

document.getElementById('btnreload').addEventListener('click',async function () {
   var fbadstatus = await init()
   if (!fbadstatus){
      var load = document.getElementById('loadspan');
      load.innerHTML = `[LỖI] Chương trình này chỉ chạy khi bạn đã đăng nhập facebook!`
      return
   }
   $('.load').delay(0).fadeOut('fast');
   reload(fbadstatus.token, fbadstatus.fbdt)
})


function clearloadData(id){
  $(id).delay(0).fadeOut('fast');
}

var tabLinks = document.querySelectorAll(".tablinks");
var tabContent = document.querySelectorAll(".tabcontent");

tabLinks.forEach(function (el) {
   el.addEventListener("click", openTabs);
});


function openTabs(el) {
   var btn = el.currentTarget; // lắng nghe sự kiện và hiển thị các element
   var electronic = btn.dataset.electronic; // lấy giá trị trong data-electronic

   tabContent.forEach(function (el) {
      el.classList.remove("active");
   }); //lặp qua các tab content để remove class active

   tabLinks.forEach(function (el) {
      el.classList.remove("active");
   }); //lặp qua các tab links để remove class active

   document.querySelector("#" + electronic).classList.add("active");
   // trả về phần tử đầu tiên có id="" được add class active

   btn.classList.add("active");
   // các button mà chúng ta click vào sẽ được add class active
}

document.getElementById('quicklink').addEventListener('change', function () {
   window.open(this.value, '_blank')
});
document.getElementById('listBM').addEventListener('change', function () {
   var currentBM = this.value;
   renderPixel(currentBM)

});

document.getElementById('btnclose').addEventListener('click', function () {
   window.close();
})
document.getElementById('btntab').addEventListener('click', function () {
   chrome.windows.create({'url': 'popup.html', 'type': 'popup', height: 520, width: 815, top: 200, left: 200}, function(window) {
   });
})


document.getElementById('btn_export').addEventListener('click', async function (e) {
   btn = document.getElementById('btn_export')
   btn.style.backgroundColor = 'brown'
   url = 'https://script.google.com/macros/s/AKfycbynUD9RYvufL6bPsokKlJkCMXdyk3pmLNnwpxomXlfSo9laYVuR4VP8yMcMwZml3wsfGw/exec'
   let objPayment = await chrome.storage.local.get(['objPayment'])

   if(objPayment==undefined){
      alert('Chưa có dữ liệu, vui lòng truy thử lại')
      return
   }
   let objAds = await chrome.storage.local.get(['objAds'])
   let objBM = await chrome.storage.local.get(['objBM']);
   objPayment = objPayment.objPayment
   objAds = JSON.parse(objAds.objAds)
   objBM = JSON.parse(objBM.objBM)
   for(var acc of objAds){
      acc.payments = objPayment[acc.id]
   }
   objALL = {
      'ad': objAds,
      'bm' : objBM
   }
   let formData = new FormData();
   formData.append('data', JSON.stringify(objALL));
   let response = await reqAPI(url, 'POST', {}, formData)
   window.open('https://docs.google.com/spreadsheets/d/106nDGY43CmyJctxeyXUu4lF0wvIcoUJ_elZDVPwxVNw/edit#gid=0', '_blank').focus();
})

document.getElementById('btn_currency').addEventListener('click', function (e) {
      btn = document.getElementById("btn_currency")
      
      if (btn.style.backgroundColor=='blue'){ 
         btn.style.backgroundColor='green'
       }else{
         btn.style.backgroundColor='blue'
       }

      if ( btn.style.backgroundColor=='blue'){  
         document.querySelectorAll('.r').forEach(function(el) {
            el.style.display = 'none';
         });
         document.querySelectorAll('.g').forEach(function(el) {
            el.style.display = 'inline';
         });
      }else{
         document.querySelectorAll('.r').forEach(function(el) {
            el.style.display = 'inline';
         });
         document.querySelectorAll('.g').forEach(function(el) {
            el.style.display = 'none';
         });
      }

})