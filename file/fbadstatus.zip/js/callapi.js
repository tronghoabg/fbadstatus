async function reqAPI(url, method, header, body) {
    let response = await fetch(
        url,
        {
            method: method,
            body: body,
            headers: header
        })
    
    let html = await response.text().then((res) => res)
    return html;
}

async function getToken() {
    let url0 = 'https://www.facebook.com/adsmanager/manage/campaigns'
    let url1 = 'https://business.facebook.com/adsmanager/manage/accounts';
    let url2 = 'https://business.facebook.com/adsmanager/manage/accounts?act='

    var json = await reqAPI(url0, 'GET');
    var flag = json.indexOf('__accessToken=')
    var token = 'NO'
    var fbdt = "NO"
    if(flag<0){
        json = await reqAPI(url1, 'GET');
        flag = json.indexOf('adAccountId: \\"')
        if(flag<0){
            var obj = {
                "token": token,
                "fbdt": fbdt
            }
            return obj;
        }else{
            accadsid = json.split('adAccountId: \\"')[1].split('\\"')[0];
            json = await reqAPI(url2 + accadsid, 'GET')
            token = json.split('window.__accessToken="')[1].split('"')[0];
            fbdt= json.split('["DTSGInitData",[],{"token":"')[1].split('"')[0]
        }
    }else{
        token = json.split('window.__accessToken="')[1].split('"')[0];
        fbdt= json.split('["DTSGInitData",[],{"token":"')[1].split('"')[0]
    }
    var obj = {
        "token": token,
        "fbdt": fbdt
    }
    return obj;
}

async function getTokenEAAG(idBm){
    let url = 'https://business.facebook.com/settings/people/' + idBm + ' ?business_id=' + idBm;
    let json = await reqAPI(url, 'GET');
    let token = json.split('accessToken":"')[2].split('"')[0];;
    chrome.tokenEAAG = token;
    return token;
}

async function main(token, fbdt) {
    getListAccInfo(token, fbdt);
    getStatusBM(token, fbdt);
    getStatusFanPage(token);
}


async function getStatusFanPage(token) {
    let url = 'https://graph.facebook.com/v15.0/me?fields=accounts.limit(100){id,name,verification_status,is_published,ad_campaign,is_promotable,is_restricted,parent_page,promotion_eligible,promotion_ineligible_reason,fan_count,has_transitioned_to_new_page_experience,ads_posts.limit(100),picture}&access_token=' + token;
    let json = await reqAPI(url, 'GET')
    let obj = JSON.parse(json);
    if('accounts' in obj){
        clearloadData('.loaddata3')
        let objList = obj['accounts']['data']
        var arrFan = [];
        for (var fan of objList) {
            var objFan = {
                img: null,
                id: null,
                name: null,
                status: null,
                promotable: null,
                likecount: null,
                ads: null,
            }

            for (var f in fan) {
                switch (f) {
                    case 'picture':
                        url = fan[f]['data']['url']
                        objFan.img = url;
                        break;
                    case 'id':
                        objFan.id = fan[f];
                        break;
                    case 'name':
                        objFan.name = fan[f];
                        break;
                    case 'verification_status':
                        objFan.status = fan[f];
                        break;
                    case 'is_promotable':
                        objFan.promotable = fan[f];
                        break;
                    case 'fan_count':
                        objFan.likecount = fan[f];
                        break;
                    case 'ads_posts':
                        objFan.ads = fan[f]['data'].length;
                        break;
                    default:
                        objFan.ads = 0;
                }
            }
            renderFan(objFan)
            arrFan.push(objFan)
        }
    }else{
        clearloadData('.loaddata3')
        var tableBM = document.getElementById('tbFanPage');
            tableBM.innerHTML = '<p>....</p>'
            clearloadData('.loaddata3')
        var arrFan = []
    }
    //localStorage.setItem('objFan', JSON.stringify(arrFan))
    chrome.storage.local.set({ 'objFan': JSON.stringify(arrFan)});
    //renderHtmlFan(arrFan);
}
function renderFan(obj){
    var tb = document.getElementById('tbFanPage')
    var result = '';
    var line_html = ''
    for(var e in obj){
        if (e == 'img') {
            line_html += `<td class="tdInfo"><img src=${obj[e]}></img></td>`
        } else {
            line_html += `<td class="tdInfo">${obj[e]}</td>`
        }
    }
    result = `<tr class="trInfo">${line_html}</tr>`
    tb.innerHTML+=result
}
function renderHtmlFan(arrObj) {
    var tableBM = document.getElementById('tbFanPage');
    if(arrObj.length==0){
        tableBM.innerHTML = '<p>....</p>'
        clearloadData('.loaddata3')
        return
    }
    var result = ''
    let html = arrObj.map(function (arr) {
        result += `<tr class="trInfo">`
        for (var a in arr) {
            if (a == 'img') {
                result += `<td class="tdInfo"><img src=${arr[a]}></img></td>`
            } else {
                result += `<td class="tdInfo">${arr[a]}</td>`
            }
        }
        result += `</tr">`
    })
    clearloadData('.loaddata3')
    tableBM.innerHTML += result;
}

function renderHtmlCamp(arrObj) {
    var tableCamp = document.getElementById('tbCamp');
    clearloadData('.loaddata4')
    if(arrObj.length==0){
        tableBM.innerHTML = '<p>No Fan Campaign</p>'
        return
    }
    var result = ''
    let html = arrObj.map(function (arr) {
        result += `<tr class="trInfo">`
        for (var a in arr) {
            txt = arr[a]
            if(a=='campaign_name'){
                txt = txt.slice(0,20)
            }
            result += `<td class="tdInfo">${txt}</td>`
        }
        result += `</tr">`
    })
    clearloadData('.loaddata3')
    tableCamp.innerHTML += result;
}


async function getStatusBM(token, fbdt) {
    let url = 'https://graph.facebook.com/v15.0/me/businesses?fields=id,created_time,is_disabled_for_integrity_reasons,sharing_eligibility_status,allow_page_management_in_www,can_use_extended_credit,name,timezone_id,timezone_offset_hours_utc,verification_status,owned_ad_accounts{account_status},client_ad_accounts{account_status},owned_pages,client_pages,business_users,owned_pixels{name}&access_token=' + token;
    let json = await reqAPI(url, 'GET')
    let obj = JSON.parse(json);
    console.log(obj)
    if (obj.data.length>0){
        clearloadData('.loaddata2')
        let objList = obj.data
        var arrBM = [];
        for (var bm of objList) {
            var objBM = {
                status: null,
                id: null,
                name: null,
                levelBm: '*',
                limit: null,
                timezone: null,
                datecreate: null,
                pixel: [],
                adminhide: 0,
            };

            for (var info in bm) {
                switch (info) {
                    case 'id':
                        objBM.id = bm[info];
                        break;
                    case 'name':
                        objBM.name = bm[info];
                        break;
                    case 'allow_page_management_in_www':
                        if(bm[info]){
                            objBM.status = "Hoạt động"
                        }else{
                            objBM.status = "Vô hiệu"
                        }
                        break;
                    case 'can_use_extended_credit':
                        if (bm[info]) {
                            objBM.limit = '$250+';
                        } else {
                            objBM.limit = bm[info];
                        }

                        break;
                    case 'timezone_id':
                        objBM.timezone = bm[info] + ':' + objTimeZone[bm[info]];
                        break;
                    case 'created_time':
                        objBM.datecreate = bm[info].slice(0, 10);
                        break;
                    case 'owned_pixels':

                        var ArrPixcel = [];
                        for (var j of bm[info]['data']) {
                            let id = j['id'];
                            let name = j['name'];
                            objBM.pixel.push({
                                id: id,
                                name: name
                            })
                        }
                        break;
                    
                }
            }
            renderBM(objBM)
            arrBM.push(objBM)
        }

        var tokenEAAG = await getTokenEAAG(arrBM[0]['id']);

        for(var b of arrBM) {
            let idbm = b['id'];
            getBmlimit(idbm, fbdt);
            CheckAdminHide(idbm, token, tokenEAAG)
        }
    }else{
        clearloadData('.loaddata2')
        var tableBM = document.getElementById('tbBM');
            tableBM.innerHTML = '<p>....</p>'
            clearloadData('.loaddata2')
        var arrBM = []
    }
    
    chrome.storage.local.set({ 'objBM': JSON.stringify(arrBM)});
}

async function renderBM(obj){
    var tb = document.getElementById('tbBM')
    var selectBM = document.getElementById('listBM');
    var result = '';
    var line_html = ''
    for(var e in obj){
        switch (e){
            case 'id':
                listBM = `<option>${obj[e]}</option>`
                line_html += `<td class="tdInfo">${obj[e]}</td>`
                break
            case 'pixel':
                line_html += `<td class="tdInfo">${obj[e].length}</td>`
                break
            case 'levelBm':
                line_html += `<td class="tdInfo" id="${obj['id']}_LV">${obj[e]}</td>`
                break
            case 'adminhide':
                line_html += `<td class="tdInfo" id="${obj['id']}_adminhide">${obj[e]}</td>`
                break
            default:
                line_html += `<td class="tdInfo">${obj[e]}</td>`
                break
        }
    }
    result = `<tr class="trInfo">${line_html}</tr">`
    tb.innerHTML+=result
    selectBM.innerHTML+=listBM;
}



async function getBmlimit(idBm, fbdt){
    let url = 'https://business.facebook.com/business/adaccount/limits/?business_id=' + idBm + '&__a=1&fb_dtsg=' + fbdt;
    let json = await reqAPI(url, 'GET')
    var levelBM = '-'
    try{
        let bmLimit = json.split('adAccountLimit":')[1].split('}')[0];
        levelBM = bmLimit
    }catch{

    };

    let element = document.getElementById(idBm + '_LV')
    element.innerHTML = levelBM
    //let tempObj = JSON.parse(localStorage.getItem('objBM'))
    let tempObj = await chrome.storage.local.get(['objBM']);
    tempObj = JSON.parse(tempObj.objBM)
    for(var e of tempObj){
        if(e.id==idBm){
            e.levelBm =levelBM
            break
        }
    }
    //localStorage.setItem('objBM', JSON.stringify(tempObj))
    chrome.storage.local.set({ 'objBM': JSON.stringify(tempObj)});
}



async function CheckAdminHide(idbm, token, tokenEAAG){
    let countAdminEAAG = await CheckAdminhideEAAG(idbm, tokenEAAG)
    let countAdminEAAB = await CheckAdminhideEAAB(idbm, token)
    var countAdminHide = countAdminEAAB - countAdminEAAG
    let element = document.getElementById(idbm + '_adminhide')
    element.innerHTML=countAdminEAAB

    let tempObj = await chrome.storage.local.get(['objBM']);
    tempObj = JSON.parse(tempObj.objBM)
    for(var e of tempObj){
        if(e.id==idbm){
            e.adminhide=countAdminEAAB
            break
        }
    }
    chrome.storage.local.set({ 'objBM': JSON.stringify(tempObj)});
}

async function CheckAdminhideEAAG(idbm, tokenEAAG){
    let url = 'https://graph.facebook.com/v14.0/'+ idbm +'/business_users?access_token=' + tokenEAAG + '&fields=email,+first_name,+last_name,+id,+pending_email,+role&limit=300&locale=en_US'
    let json = await reqAPI(url, 'GET')
    let obj = JSON.parse(json);
    let objList = obj.data
    return  objList.length;
}

async function CheckAdminhideEAAB(idbm , token){
    let url = 'https://graph.facebook.com/v14.0/'+ idbm +'/business_users?access_token=' + token + '&fields=email,+first_name,+last_name,+id,+pending_email,+role&limit=300&locale=en_US'
    let json = await reqAPI(url, 'GET')
    let obj = JSON.parse(json);
    let objList = obj.data
    return  objList.length;
}

function renderHtmlBM(arrObj) {
    var tableBM = document.getElementById('tbBM');
    var selectBM = document.getElementById('listBM');
    if(arrObj.length==0){
        tableBM.innerHTML = '<p>....</p>'
        clearloadData('.loaddata2')
        return
    }
    var result = '';
    var listBM = '';
    let html = arrObj.map(function (arr) {
        result += `<tr class="trInfo">`
        for (var a in arr) {
            if (a == 'id') {
                listBM += `<option>${arr[a]}</option>`
            }
            if (a == 'pixel') {
                result += `<td class="tdInfo">${arr[a].length}</td>`
            } else {
                result += `<td class="tdInfo">${arr[a]}</td>`
            }

        }
        result += `</tr">`
    })

    clearloadData('.loaddata2')
    tableBM.innerHTML += result;
    selectBM.innerHTML = listBM;
    var currentBM = selectBM.value
    renderPixel(currentBM)
}


async function renderPixel(currentBM) {
    //let objBM = JSON.parse(localStorage.getItem('objBM'))
    let objBM = await chrome.storage.local.get(['objBM']);
    objBM = JSON.parse(objBM.objBM)
    var optionHTML = '';
    for (var b of objBM) {
        if (b['id'] == currentBM) {
            if (b['pixel'].length < 1) {
                optionHTML += `<option>Dose have an account!</option>`
            }
            for (var px of b['pixel']) {
                optionHTML += `<option value='${px['id']}'>${px['id']} | ${px['name']}</option>`
            }
        }
    }
    var listPixel = document.getElementById('listPixel');
    listPixel.innerHTML = optionHTML;
}



document.getElementById('btnSharePixe').addEventListener('click', async function () {
    var idBm = document.getElementById('listBM').value;
    var idPixel = document.getElementById('listPixel').value;
    var listPixelId = document.getElementById('listPixelId').value;
    let token = await chrome.storage.local.get(['token'])
    token = token.token

    var arrlistPixelId = listPixelId.split("\n");

    if (listPixelId.length < 1) {
        alert('Vui lòng nhập ID TKQC', 3000)
        return
    }
    if (idPixel.slice(0, 2) != 'Do') {
        var logHtml = document.getElementById('logsatusSharePixel');
        logHtml.innerHTML = '';
        chrome.logHtml = ''

        for (var idAds of arrlistPixelId) {
            btnSharePixe(token, idBm, idPixel, idAds)
        }
    } else {
        alert('Không có TKQC!', 3000)
        return;
    }
});

async function btnSharePixe(token, idBm, idPixel, idAds) {
    url = "https://graph.facebook.com/v15.0/" + idPixel + "/shared_accounts"
    let formData = new FormData();
    formData.append('account_id', idAds);
    formData.append('business', idBm);
    formData.append('access_token', token);
    let response = await reqAPI(url, 'POST', {}, formData)
    let obj = JSON.parse(response);

    if (obj['success']) {
        chrome.logHtml += `<li>${idAds} : success: true</li>`
    } else {
        chrome.logHtml += `<li> ${idAds} : error</li>`
    }
    var logHtml = document.getElementById('logsatusSharePixel');
    logHtml.innerHTML = chrome.logHtml;
}

function renderCampaign(obj){
    var tb = document.getElementById('tbCamp')
    var result = '';
    var line_html = ''
    for(var e in obj){
        txt = obj[e]
        if(e=='campaign_name'){
            txt = txt.slice(0,20)
        }
        line_html += `<td class="tdInfo">${txt}</td>`
    }
    result = `<tr class="trInfo">${line_html}</tr>`
    tb.innerHTML+=result
}

async function getCampaign(acc, token){
    var url0 = 'https://graph.facebook.com/v15.0/' + acc + '/campaigns?date_preset=last_90d&fields=id,status,daily_budget,lifetime_budget,start_time,stop_time&access_token='+ token
    var json0 = await reqAPI(url0, 'GET')
    var obj0 = JSON.parse(json0);

    if('data' in obj0){
       var objBudget = obj0.data
    }
    var url = 'https://graph.facebook.com/v15.0/' + acc + '/insights?date_preset=last_90d&level=adset&fields=account_id,campaign_id,campaign_name,impressions,ctr,cpc,cpm,spend,account_currency,clicks,conversions,actions,converted_product_quantity&access_token='+ token
    var json = await reqAPI(url, 'GET')
    var obj = JSON.parse(json);
    var arrCamp = []
    if('data' in obj){
        clearloadData('.loaddata4')
        objCampaign = obj.data
        if(objCampaign.length<1){
            return
        }
        for(let camp of objCampaign){
            var objCamp = {
                account_id: '.' + acc,
                status: '',
                campaign_name: '',
                impressions: '',
                clicks: '',
                cpm: '',
                cpc: '',
                ctr: '',
                spend: '',
                lifetime_budget: '',
                account_currency: '',
                start_time: '',
                stop_time: '',
            }
            for(var e in objCamp){
                switch(e){
                    case 'status':
                        for(let objbig of objBudget){
                            if(camp.campaign_id == objbig.id){
                                objCamp[e] = objbig.status
                                break
                            }
                        }
                    break
                    case 'lifetime_budget':
                        for(let objbig of objBudget){
                            if(camp.campaign_id == objbig.id){
                                objCamp[e] = objbig.lifetime_budget
                                break
                            }
                        }
                    break
                    case 'start_time':
                        for(let objbig of objBudget){
                            if(camp.campaign_id == objbig.id){
                                objCamp[e] = objbig.start_time.slice(0,10)
                                break
                            }
                        }
                    break
                    case 'stop_time':
                        for(let objbig of objBudget){
                            if(camp.campaign_id == objbig.id && (e in objbig)){
                                objCamp[e] = objbig.stop_time.slice(0,10)
                                break
                            }
                        }
                    break
                    case 'cpm':
                        objCamp[e] = Number(camp[e]).toFixed(2)
                    break
                    case 'cpc':
                        objCamp[e] = Number(camp[e]).toFixed(2)
                    break
                    case 'ctr':
                        objCamp[e] = Number(camp[e]).toFixed(2)
                    break

                default:
                       objCamp[e] = camp[e]
                }

            }
            renderCampaign(objCamp)
            arrCamp.push(objCamp)
            }
        }
        tempObj = await chrome.storage.local.get(['objCamp']);
        tempObj = JSON.parse(tempObj.objCamp)
        tempObj.push(...arrCamp)
        chrome.storage.local.set({ 'objCamp': JSON.stringify(tempObj)});
}

async function getPayment(act, fbdt){
    let objPayment = await getCard(act, fbdt)
    let bills = await getBills(objPayment.id, fbdt)
    var tempObj = await chrome.storage.local.get(['objPayment']);
    tempObj = tempObj.objPayment
    obj = {
        'act': act,
        'payments': objPayment.payment,
        'bills': bills
    }
    return obj
}

async function getBills(act, fbdt){
    url = 'https://business.facebook.com/api/graphql/'
    let formData = new FormData();
    formData.append('fb_dtsg', `${fbdt}`);
    formData.append('variables', `{"count":20,"cursor":null,"end_time":${Math.round(+new Date()/1000)},"filters":[],"start_time":1339261200,"id":"${act}"}`);
    formData.append('doc_id', '5088279497901543');
    let response = await fetch(url, {
        method: 'post',
        credentials: 'include',
        mode : "cors",
        body: formData,
        headers: {
            "sec-fetch-dest":"empty",
            "sec-fetch-mode":"cors",
            "sec-fetch-site":"same-site"
        },})
    let html = await response.text().then((res) => res)
    let objJson = JSON.parse(html)
    var objData = {}
    let txt_bill = ''
    try{
        objData = objJson['data']['node']['billing_txns']['edges']
        if(objData.length>0){
            var count_paid = 0 
            var count_faild = 0
            for(var bills of objData){
                let objBill = bills.node
                txt_bill+=(objBill.status=='COMPLETED'?'✓ PAID':objBill.status) +  ' | ' + objBill.payment_method_label + ' | ' +  ' | ' + new Date(objBill.transaction_time*1000).toLocaleDateString("en-US") + ' | ' + objBill.total_amount.formatted_amount + '\n'
                if(objBill.status == 'COMPLETED'){
                    count_paid++
                }else{
                    count_faild++
                }
            }
            txt_bill = `${objData.length} Bills gần nhất | Paid: ${count_paid} | Faild: ${count_faild} \n ${txt_bill}`
        }
    }catch(ex){
        if('errors' in objJson){
            txt_bill = objJson['errors'][0]['message']
        }
    }
    return txt_bill
}

async function getCard(act, fbdt){
    url = 'https://business.facebook.com/api/graphql/'
    let formData = new FormData();
    formData.append('variables', `{"paymentAccountID":"${act}"}`);
    formData.append('doc_id', '5369940383036972');
    formData.append('fb_dtsg', fbdt);


    let response = await fetch(url, {
        method: 'post',
        credentials: 'include',
        mode : "cors",
        body: formData,
        headers: {
            "sec-fetch-dest":"empty",
            "sec-fetch-mode":"cors",
            "sec-fetch-site":"same-site"
        },})
    let html = await response.text().then((res) => res)
    let objJson = JSON.parse(html)
    var listCard = ''
    var id_act = ''
    var obj = {}
    if('data' in objJson){
        let objCard = ''
        try{
            id_act = objJson['data']['billable_account_by_payment_account']['billing_payment_account']['id']
            objCard = objJson['data']['billable_account_by_payment_account']['billing_payment_account']['billing_payment_methods']
        }catch(e){
            obj = {
                id: act,
                payment: listCard
            }
            return obj
        }
        for(var card of objCard){
            var usability = card['usability']
            switch(usability){
                case("USABLE"):
                    usability = 'Usable'
                    break
                case 'UNVERIFIED_OR_PENDING_AUTH':
                    usability = 'Need'
                    break;
                case 'UNVERIFIABLE':
                    usability = 'Unverifiable'
                    break;
                case 'ADS_PAYMENTS_RESTRICTED':
                    usability = 'Restricted'
                    break;
            }
            card = card['credential']
            if (card['__typename'] == 'ExternalCreditCard'){
                listCard+=card['card_association_name'] + ': ' + usability + ' | Expires on: ' + card['expiry_month'] + '/' + card['expiry_year'] + '\n'
            }else if(card['__typename'] == 'DirectDebit'){
                listCard+= 'Banking(DirectDebit): ' + usability + '\n '
            }else if(card['__typename'] == 'AdsToken' || card['__typename'] == 'StoredBalance'){
               
            }else{
                listCard+= '(' + card['__typename'] + ': ' + usability + '\n '
            }
        }
    }else if('errors' in objJson){
        listCard = objJson['errors'][0]['message']
        obj = {
            id: act,
            payment: listCard
        }
        return obj
    }
    obj = {
        id: id_act,
        payment: (listCard.indexOf('\n') ? listCard.slice(0,listCard.length-1) : listCard)
    }
    return obj
}


async function getListAccInfo(token, fbdt) {
    let url = 'https://graph.facebook.com/v15.0/me/adaccounts?fields=id,account_id{adspaymentcycle{threshold_amount}},business,name,adtrust_dsl,currency,account_status,balance,current_unbilled_spend,amount_spent,account_currency_ratio_to_usd,users,user_role,assigned_partners,adspaymentcycle,ads.limit(1000){effective_status}&limit=1000&sort=name_ascending&access_token=' + token;
    let json = await reqAPI(url, 'GET')
    let obj = JSON.parse(json);
    let objListACC = obj.data
    clearloadData('.loaddata1')
    var arrAcc = []
    var arrCamp = []
    chrome.storage.local.set({ 'objCamp': JSON.stringify(arrCamp)});
    for (var acc of objListACC) {
        getCampaign(acc.id, token)
        var objAcc = {
            s_status: '',
            s_id: 'null',
            s_name: '',
            s_balance: '',
            s_threshold: '*',
            s_adtrust: '',
            s_spent: '',
            s_admin: '',
            s_currency: '',
            s_acctype: '',
            h_balance: '',
            h_threshold: '*',
            h_adtrust: '',
            h_spent: '',
            h_bm: '',
        }

        usd_rate = acc.account_currency_ratio_to_usd
        
        objAcc.s_status =  getStatusAcc(acc.account_status)
        objAcc.s_id = acc.account_id
        objAcc.s_name = acc.name
        objAcc.s_balance =  Math.round(((acc.balance * 0.01)+ Number.EPSILON) * 100) / 100
        if(acc.adspaymentcycle){
            let threshold = acc.adspaymentcycle.data[0].threshold_amount * 0.01
            objAcc.s_threshold = Math.round((threshold+ Number.EPSILON) * 100) / 100
        }else{
            objAcc.s_threshold = 0
        }
        objAcc.s_adtrust = ((acc.adtrust_dsl==-1)?'No limit': acc.adtrust_dsl)
        objAcc.s_spent = Math.round(((acc.amount_spent * 0.01)+ Number.EPSILON) * 100) / 100
        objAcc.s_admin = acc.users['data'].length
        objAcc.s_currency = acc.currency
        objAcc.s_acctype = (acc.business? 'BM': 'Cá nhân')
        
        objAcc.h_balance = Math.round(((objAcc.s_balance/usd_rate)+ Number.EPSILON) * 100) / 100
        objAcc.h_threshold = Math.round(((objAcc.s_threshold/usd_rate)+ Number.EPSILON) * 100) / 100
        objAcc.h_adtrust = objAcc.s_adtrust!='No limit'? Math.round(((objAcc.s_adtrust/usd_rate)+ Number.EPSILON) * 100) / 100: 'No Limit'
        objAcc.h_spent = Math.round(((objAcc.s_spent/usd_rate)+ Number.EPSILON) * 100) / 100
        objAcc.h_bm =  (acc.business? acc.business.id: '-')
        renderAds(objAcc)
        arrAcc.push(objAcc);
    }
    chrome.storage.local.set({'objAds': JSON.stringify(arrAcc)});
}

function renderAds(obj){
    var tb = document.getElementById('tb')
    var result = '';
    var line_html = ''
    console.log(obj)
    for(var e in obj){
        if(e.slice(0,2)=='s_'){
            switch(e){
                case 's_id':
                    line_html += `<td class="tdInfo"><a title="Tới trang quản lý chiến dịch" href="#">${obj[e]}</a></td>`
                    break
                case 's_balance':
                    line_html += `<td class="tdInfo"><span id="r" class="r">${obj[e]}</span><span id="g" class="g">${obj['h_balance']}</span></td>`
                    break
                case 's_adtrust':
                    line_html += `<td class="tdInfo"><span id="r" class="r">${obj[e]}</span><span id="g" class="g">${obj['h_adtrust']}</span></td>`
                    break
                case 's_spent':
                    line_html += `<td class="tdInfo"><span id="r" class="r">${obj[e]}</span><span id="g" class="g">${obj['h_spent']}</span></td>`
                break
                case 's_threshold':
                    line_html += `<td class="tdInfo"><span id="r" class="r">${obj[e]}</span><span id="g" class="g">${obj['h_threshold']}</span></td>`
                break
                default:
                    line_html += `<td class="tdInfo">${obj[e]}</td>`
            }
        }
    }
    result = `<tr class="trInfo">${line_html}</tr>`
    tb.innerHTML+=result
}


function renderHtmlAcc(arrObj) {
    var tb = document.getElementById('tb');
    if(arrObj.length==0){
        clearloadData('.loaddata1')
        tb.innerHTML = '<p>No Ads Account</p>'
        return
    }
    var result = '';
    var line_html = '';
    let html = arrObj.map(function (obj) {
        var line_html = '';
        for(var e in obj){
            if(e.slice(0,2)=='s_'){
                switch(e){
                    case 's_balance':
                        line_html += `<td class="tdInfo"><span id="r" class="r">${obj[e]}</span><span id="g" class="g">${obj['h_balance']}</span></td>`
                        break
                    case 's_adtrust':
                        line_html += `<td class="tdInfo"><span id="r" class="r">${obj[e]}</span><span id="g" class="g">${obj['h_adtrust']}</span></td>`
                        break
                    case 's_spent':
                        line_html += `<td class="tdInfo"><span id="r" class="r">${obj[e]}</span><span id="g" class="g">${obj['h_spent']}</span></td>`
                    break
                    case 's_threshold':
                        line_html += `<td class="tdInfo"><span id="r" class="r">${obj[e]}</span><span id="g" class="g">${obj['h_threshold']}</span></td>`
                    break
                    default:
                        line_html += `<td class="tdInfo">${obj[e]}</td>`
                }
            }
        }
        result+= `<tr class="trInfo">${line_html}</tr>`
    })

    clearloadData('.loaddata1')
    tb.innerHTML += result;
}

async function createCamp(act,budget){
    let token = await chrome.storage.local.get(['token']); token = token.token
    var obj = {
        "name": "Fbadstatus auto create Campaign",
        "objective": "OUTCOME_SALES",
        "status": "PAUSED",
        "special_ad_categories": "[]"
    }
    var formData = new FormData();
    formData.append('access_token', token);
    Object.keys(obj).forEach(key => formData.append(key, obj[key]));
 
    let url = `https://graph.facebook.com/v15.0/act_${act}/campaigns`
    let response = await reqAPI(url , 'POST', {}, formData)
    var obj = JSON.parse(response);
    return obj
}

async function createAdGroup(act, campaign_id, pixel_id, budget, min_age, max_age){
    const today = new Date();
    const day = today.getDate().toString().padStart(2, "0");
    const month = (today.getMonth() + 1).toString().padStart(2, "0");
    const year = today.getFullYear();
    const formattedDate = `${day}-${month}-${year}`;

    let token = await chrome.storage.local.get(['token']); token = token.token
    var target = {
        "age_min": min_age,
        "age_max": max_age,
        "genders": [
        ],
        "geo_locations": {
          "countries": [
            "US"
          ],
          "location_types": [
            "home",
            "recent"
          ]
        },
        "excluded_geo_locations": {
          "regions": [
            {
              "key": "3844",
              "name": "Alaska",
              "country": "US"
            },
            {
              "key": "3854",
              "name": "Hawaii",
              "country": "US"
            }
          ]
        },
        "publisher_platforms": ["facebook"],
        "facebook_positions":["feed","facebook_reels","facebook_reels_overlay"],
        "device_platforms": ["mobile", "desktop"],
    }

    var obj = {
        "name": "Fbadstatus auto create Ad Group",
        "campaign_id": campaign_id,
        "start_time": formattedDate,
        "bid_strategy": "LOWEST_COST_WITHOUT_CAP",
        "daily_budget": budget * 100,
        "billing_event": "IMPRESSIONS",
        "optimization_goal": "REACH",
        "promoted_object": `{"pixel_id": ${pixel_id},"custom_event_type":"PURCHASE"}`,
        "optimization_goal": "OFFSITE_CONVERSIONS",
        "objective": "OUTCOME_SALES",
      
        "targeting": JSON.stringify(target),
        "brand_safety_content_filter_levels": ["FACEBOOK_STANDARD"]
      }
    var formData = new FormData();
    formData.append('access_token', token);
    Object.keys(obj).forEach(key => formData.append(key, obj[key]));
 
    let url = `https://graph.facebook.com/v15.0/act_${act}/adsets`
    let response = await reqAPI(url , 'POST', {}, formData)
    var obj = JSON.parse(response);
    return obj

}

async function createAdcreative(act, story_id, ){
    let token = await chrome.storage.local.get(['token']); token = token.token
    var obj = {
        "name":"Fbadstatus AD creative",
        "object_story_id": story_id
      }
    var formData = new FormData();
    formData.append('access_token', token);
    Object.keys(obj).forEach(key => formData.append(key, obj[key]));
 
    let url = `https://graph.facebook.com/v15.0/act_${act}/adcreatives`
    let response = await reqAPI(url , 'POST', {}, formData)
    var obj = JSON.parse(response);
    return obj
}


async function createAds(act, AdGroup_id, adCreative_id){
    let token = await chrome.storage.local.get(['token']); token = token.token
    var obj = {
        "name": "Fbadstatus Ads",
        "adset_id": AdGroup_id,
        "creative": JSON.stringify({
          "creative_id": adCreative_id
        }),
        "status": "PAUSED"
      }
    var formData = new FormData();
    formData.append('access_token', token);
    Object.keys(obj).forEach(key => formData.append(key, obj[key]));
 
    let url = `https://graph.facebook.com/v15.0/act_${act}/ads`
    let response = await reqAPI(url , 'POST', {}, formData)
    var obj = JSON.parse(response);
    return obj

}
async function addCallActionType(page,post,act,action_type,action_link){
    let fbdt = await chrome.storage.local.get(['fbdt']); fbdt = fbdt.fbdt

    var url = `https://business.facebook.com/ads/existing_post/call_to_action/?post_ids[0]=${post}&page_ids[0]=${page}&ad_account_id=${act}&source_app_id=119211728144504&call_to_action_type=${action_type}&call_to_action_link=${action_link}`
    var formdata = new FormData()
    formdata.append('fb_dtsg', fbdt);
    formdata.append("__a", "1")
    let response = await reqAPI(url , 'POST', {}, formdata)
    let flag = response.indexOf('success')
    if(flag>0){
        return response
    }
    return false

}

async function create_ad_in_bm(bm, name, timezone){
    let token = await chrome.storage.local.get(['token']); token = token.token
    let url = `https://graph.facebook.com/v14.0/${bm}/adaccount?access_token=${token}&__cppo=1`
    var formdata = new FormData();
    formdata.append("currency", "USD");
    formdata.append("end_advertiser", bm);
    formdata.append("media_agency", "UNFOUND");
    formdata.append("name", name);
    formdata.append("partner", "UNFOUND");
    formdata.append("timezone_id", timezone);
    let response = await reqAPI(url , 'POST', {}, formdata)
    var obj = JSON.parse(response);
    if('id' in obj){
        return 'Tạo thành công '+ obj.id
    }
    if('error' in obj){
        return 'Sảy ra lỗi| '+ obj.error.message
    }
}
function getStatusAcc(num) {
    let astatus = ''
    switch (num) {
        case 1:
            astatus = 'Active';
            break; ///active
        case 2:
            astatus = 'Disable';
            break; //disabled
        case 3:
            astatus = 'Dư Nợ';
            break;
        case 7:
            astatus = "Pending Review"; //PENDING_RISK_REVIEW 
            break;
        case 8:
            astatus = "Pending Settlement";
            break;
        case 9:
            astatus = "Ân hạn"; //IN_GRACE_PERIOD In 
            break;
        case 100:
            astatus = 'Pending Closure';
            break;
        case 101:
            astatus = 'Đóng';
            break;
        case 201:
            astatus = "Any Active";
            break;
        case 202:
            astatus = "Any Close";
            break;
        default:
            astatus = "Unknow"
            break;
    }
    return astatus
}

objTimeZone = {
    0: 'TZ_UNKNOWN',
    1: 'America_Los_Angeles',
    2: 'America_Denver',
    3: 'Pacific_Honolulu',
    4: 'America_Anchorage',
    5: 'America_Phoenix',
    6: 'America_Chicago',
    7: 'America_New_York',
    8: 'Asia_Dubai',
    9: 'America_Argentina_San_Luis',
    10: 'America_Argentina_Buenos_Aires',
    11: 'America_Argentina_Salta',
    12: 'Europe_Vienna',
    13: 'Australia_Perth',
    14: 'Australia_Broken_Hill',
    15: 'Australia_Sydney',
    16: 'Europe_Sarajevo',
    17: 'Asia_Dhaka',
    18: 'Europe_Brussels',
    19: 'Europe_Sofia',
    20: 'Asia_Bahrain',
    21: 'America_La_Paz',
    22: 'America_Noronha',
    23: 'America_Campo_Grande',
    24: 'America_Belem',
    25: 'America_Sao_Paulo',
    26: 'America_Nassau',
    27: 'America_Dawson',
    28: 'America_Vancouver',
    29: 'America_Dawson_Creek',
    30: 'America_Edmonton',
    31: 'America_Rainy_River',
    32: 'America_Regina',
    33: 'America_Atikokan',
    34: 'America_Iqaluit',
    35: 'America_Toronto',
    36: 'America_Blanc_Sablon',
    37: 'America_Halifax',
    38: 'America_St_Johns',
    39: 'Europe_Zurich',
    40: 'Pacific_Easter',
    41: 'America_Santiago',
    42: 'Asia_Shanghai',
    43: 'America_Bogota',
    44: 'America_Costa_Rica',
    45: 'Asia_Nicosia',
    46: 'Europe_Prague',
    47: 'Europe_Berlin',
    48: 'Europe_Copenhagen',
    49: 'America_Santo_Domingo',
    50: 'Pacific_Galapagos',
    51: 'America_Guayaquil',
    52: 'Europe_Tallinn',
    53: 'Africa_Cairo',
    54: 'Atlantic_Canary',
    55: 'Europe_Madrid',
    56: 'Europe_Helsinki',
    57: 'Europe_Paris',
    58: 'Europe_London',
    59: 'Africa_Accra',
    60: 'Europe_Athens',
    61: 'America_Guatemala',
    62: 'Asia_Hong_Kong',
    63: 'America_Tegucigalpa',
    64: 'Europe_Zagreb',
    65: 'Europe_Budapest',
    66: 'Asia_Jakarta',
    67: 'Asia_Makassar',
    68: 'Asia_Jayapura',
    69: 'Europe_Dublin',
    70: 'Asia_Jerusalem',
    71: 'Asia_Kolkata',
    72: 'Asia_Baghdad',
    73: 'Atlantic_Reykjavik',
    74: 'Europe_Rome',
    75: 'America_Jamaica',
    76: 'Asia_Amman',
    77: 'Asia_Tokyo',
    78: 'Africa_Nairobi',
    79: 'Asia_Seoul',
    80: 'Asia_Kuwait',
    81: 'Asia_Beirut',
    82: 'Asia_Colombo',
    83: 'Europe_Vilnius',
    84: 'Europe_Luxembourg',
    85: 'Europe_Riga',
    86: 'Africa_Casablanca',
    87: 'Europe_Skopje',
    88: 'Europe_Malta',
    89: 'Indian_Mauritius',
    90: 'Indian_Maldives',
    91: 'America_Tijuana',
    92: 'America_Hermosillo',
    93: 'America_Mazatlan',
    94: 'America_Mexico_City',
    95: 'Asia_Kuala_Lumpur',
    96: 'Africa_Lagos',
    97: 'America_Managua',
    98: 'Europe_Amsterdam',
    99: 'Europe_Oslo',
    100: 'Pacific_Auckland',
    101: 'Asia_Muscat',
    102: 'America_Panama',
    103: 'America_Lima',
    104: 'Asia_Manila',
    105: 'Asia_Karachi',
    106: 'Europe_Warsaw',
    107: 'America_Puerto_Rico',
    108: 'Asia_Gaza',
    109: 'Atlantic_Azores',
    110: 'Europe_Lisbon',
    111: 'America_Asuncion',
    112: 'Asia_Qatar',
    113: 'Europe_Bucharest',
    114: 'Europe_Belgrade',
    115: 'Europe_Kaliningrad',
    116: 'Europe_Moscow',
    117: 'Europe_Samara',
    118: 'Asia_Yekaterinburg',
    119: 'Asia_Omsk',
    120: 'Asia_Krasnoyarsk',
    121: 'Asia_Irkutsk',
    122: 'Asia_Yakutsk',
    123: 'Asia_Vladivostok',
    124: 'Asia_Magadan',
    125: 'Asia_Kamchatka',
    126: 'Asia_Riyadh',
    127: 'Europe_Stockholm',
    128: 'Asia_Singapore',
    129: 'Europe_Ljubljana',
    130: 'Europe_Bratislava',
    131: 'America_El_Salvador',
    132: 'Asia_Bangkok',
    133: 'Africa_Tunis',
    134: 'Europe_Istanbul',
    135: 'America_Port_Of_Spain',
    136: 'Asia_Taipei',
    137: 'Europe_Kiev',
    138: 'America_Montevideo',
    139: 'America_Caracas',
    140: 'Asia_Ho_Chi_Minh',
    141: 'Africa_Johannesburg',
    142: 'America_Winnipeg',
    143: 'America_Detroit',
    144: 'Australia_Melbourne',
    145: 'Asia_Kathmandu',
    146: 'Asia_Baku',
    147: 'Africa_Abidjan',
    148: 'Africa_Addis_Ababa',
    149: 'Africa_Algiers',
    150: 'Africa_Asmara',
    151: 'Africa_Bamako',
    152: 'Africa_Bangui',
    153: 'Africa_Banjul',
    154: 'Africa_Bissau',
    155: 'Africa_Blantyre',
    156: 'Africa_Brazzaville',
    157: 'Africa_Bujumbura',
    158: 'Africa_Ceuta',
    159: 'Africa_Conakry',
    160: 'Africa_Dakar',
    161: 'Africa_Dar_Es_Salaam',
    162: 'Africa_Djibouti',
    163: 'Africa_Douala',
    164: 'Africa_El_Aaiun',
    165: 'Africa_Freetown',
    166: 'Africa_Gaborone',
    167: 'Africa_Harare',
    168: 'Africa_Juba',
    169: 'Africa_Kampala',
    170: 'Africa_Khartoum',
    171: 'Africa_Kigali',
    172: 'Africa_Kinshasa',
    173: 'Africa_Libreville',
    174: 'Africa_Lome',
    175: 'Africa_Luanda',
    176: 'Africa_Lubumbashi',
    177: 'Africa_Lusaka',
    178: 'Africa_Malabo',
    179: 'Africa_Maputo',
    180: 'Africa_Maseru',
    181: 'Africa_Mbabane',
    182: 'Africa_Mogadishu',
    183: 'Africa_Monrovia',
    184: 'Africa_Ndjamena',
    185: 'Africa_Niamey',
    186: 'Africa_Nouakchott',
    187: 'Africa_Ouagadougou',
    188: 'Africa_Porto_Novo',
    189: 'Africa_Sao_Tome',
    190: 'Africa_Tripoli',
    191: 'Africa_Windhoek',
    192: 'America_Adak',
    193: 'America_Anguilla',
    194: 'America_Antigua',
    195: 'America_Araguaina',
    196: 'America_Argentina_Catamarca',
    197: 'America_Argentina_Cordoba',
    198: 'America_Argentina_Jujuy',
    199: 'America_Argentina_La_Rioja',
    200: 'America_Argentina_Mendoza',
    201: 'America_Argentina_Rio_Gallegos',
    202: 'America_Argentina_San_Juan',
    203: 'America_Argentina_Tucuman',
    204: 'America_Argentina_Ushuaia',
    205: 'America_Aruba',
    206: 'America_Bahia',
    207: 'America_Bahia_Banderas',
    208: 'America_Barbados',
    209: 'America_Belize',
    210: 'America_Boa_Vista',
    211: 'America_Boise',
    212: 'America_Cambridge_Bay',
    213: 'America_Cancun',
    214: 'America_Cayenne',
    215: 'America_Cayman',
    216: 'America_Chihuahua',
    217: 'America_Creston',
    218: 'America_Cuiaba',
    219: 'America_Curacao',
    220: 'America_Danmarkshavn',
    221: 'America_Dominica',
    222: 'America_Eirunepe',
    223: 'America_Fort_Nelson',
    224: 'America_Fortaleza',
    225: 'America_Glace_Bay',
    226: 'America_Godthab',
    227: 'America_Goose_Bay',
    228: 'America_Grand_Turk',
    229: 'America_Grenada',
    230: 'America_Guadeloupe',
    231: 'America_Guyana',
    232: 'America_Havana',
    233: 'America_Indiana_Indianapolis',
    234: 'America_Indiana_Knox',
    235: 'America_Indiana_Marengo',
    236: 'America_Indiana_Petersburg',
    237: 'America_Indiana_Tell_City',
    238: 'America_Indiana_Vevay',
    239: 'America_Indiana_Vincennes',
    240: 'America_Indiana_Winamac',
    241: 'America_Indianapolis',
    242: 'America_Inuvik',
    243: 'America_Juneau',
    244: 'America_Kentucky_Louisville',
    245: 'America_Kentucky_Monticello',
    246: 'America_Kralendijk',
    247: 'America_Lower_Princes',
    248: 'America_Maceio',
    249: 'America_Manaus',
    250: 'America_Marigot',
    251: 'America_Martinique',
    252: 'America_Matamoros',
    253: 'America_Menominee',
    254: 'America_Merida',
    255: 'America_Metlakatla',
    256: 'America_Miquelon',
    257: 'America_Moncton',
    258: 'America_Monterrey',
    259: 'America_Montreal',
    260: 'America_Montserrat',
    261: 'America_Nipigon',
    262: 'America_Nome',
    263: 'America_North_Dakota_Beulah',
    264: 'America_North_Dakota_Center',
    265: 'America_North_Dakota_New_Salem',
    266: 'America_Ojinaga',
    267: 'America_Pangnirtung',
    268: 'America_Paramaribo',
    269: 'America_Port_Au_Prince',
    270: 'America_Porto_Velho',
    271: 'America_Punta_Arenas',
    272: 'America_Rankin_Inlet',
    273: 'America_Recife',
    274: 'America_Resolute',
    275: 'America_Rio_Branco',
    276: 'America_Santarem',
    277: 'America_Scoresbysund',
    278: 'America_Sitka',
    279: 'America_St_Barthelemy',
    280: 'America_St_Kitts',
    281: 'America_St_Lucia',
    282: 'America_St_Thomas',
    283: 'America_St_Vincent',
    284: 'America_Swift_Current',
    285: 'America_Thule',
    286: 'America_Thunder_Bay',
    287: 'America_Tortola',
    288: 'America_Whitehorse',
    289: 'America_Yakutat',
    290: 'America_Yellowknife',
    291: 'Antarctica_Casey',
    292: 'Antarctica_Davis',
    293: 'Antarctica_Dumontdurville',
    294: 'Antarctica_Macquarie',
    295: 'Antarctica_Mawson',
    296: 'Antarctica_Mcmurdo',
    297: 'Antarctica_Palmer',
    298: 'Antarctica_Rothera',
    299: 'Antarctica_Syowa',
    300: 'Antarctica_Troll',
    301: 'Antarctica_Vostok',
    302: 'Arctic_Longyearbyen',
    303: 'Asia_Aden',
    304: 'Asia_Almaty',
    305: 'Asia_Anadyr',
    306: 'Asia_Aqtau',
    307: 'Asia_Aqtobe',
    308: 'Asia_Ashgabat',
    309: 'Asia_Atyrau',
    310: 'Asia_Barnaul',
    311: 'Asia_Bishkek',
    312: 'Asia_Brunei',
    313: 'Asia_Chita',
    314: 'Asia_Choibalsan',
    315: 'Asia_Damascus',
    316: 'Asia_Dili',
    317: 'Asia_Dushanbe',
    318: 'Asia_Famagusta',
    319: 'Asia_Hebron',
    320: 'Asia_Hovd',
    321: 'Asia_Istanbul',
    322: 'Asia_Kabul',
    323: 'Asia_Khandyga',
    324: 'Asia_Kuching',
    325: 'Asia_Macau',
    326: 'Asia_Novokuznetsk',
    327: 'Asia_Novosibirsk',
    328: 'Asia_Oral',
    329: 'Asia_Phnom_Penh',
    330: 'Asia_Pontianak',
    331: 'Asia_Pyongyang',
    332: 'Asia_Qostanay',
    333: 'Asia_Qyzylorda',
    334: 'Asia_Sakhalin',
    335: 'Asia_Samarkand',
    336: 'Asia_Srednekolymsk',
    337: 'Asia_Tashkent',
    338: 'Asia_Tbilisi',
    339: 'Asia_Tehran',
    340: 'Asia_Thimphu',
    341: 'Asia_Tomsk',
    342: 'Asia_Ulaanbaatar',
    343: 'Asia_Urumqi',
    344: 'Asia_Ust_Nera',
    345: 'Asia_Vientiane',
    346: 'Asia_Yangon',
    347: 'Asia_Yerevan',
    348: 'Atlantic_Bermuda',
    349: 'Atlantic_Cape_Verde',
    350: 'Atlantic_Faroe',
    351: 'Atlantic_Madeira',
    352: 'Atlantic_South_Georgia',
    353: 'Atlantic_St_Helena',
    354: 'Atlantic_Stanley',
    355: 'Australia_Adelaide',
    356: 'Australia_Brisbane',
    357: 'Australia_Currie',
    358: 'Australia_Darwin',
    359: 'Australia_Eucla',
    360: 'Australia_Hobart',
    361: 'Australia_Lindeman',
    362: 'Australia_Lord_Howe',
    363: 'Cet',
    364: 'Cst6Cdt',
    365: 'Eet',
    366: 'Est',
    367: 'Est5Edt',
    368: 'Etc_Gmt',
    369: 'Etc_Gmt_Plus_0',
    370: 'Etc_Gmt_Plus_1',
    371: 'Etc_Gmt_Plus_10',
    372: 'Etc_Gmt_Plus_11',
    373: 'Etc_Gmt_Plus_12',
    374: 'Etc_Gmt_Plus_2',
    375: 'Etc_Gmt_Plus_3',
    376: 'Etc_Gmt_Plus_4',
    377: 'Etc_Gmt_Plus_5',
    378: 'Etc_Gmt_Plus_6',
    379: 'Etc_Gmt_Plus_7',
    380: 'Etc_Gmt_Plus_8',
    381: 'Etc_Gmt_Plus_9',
    382: 'Etc_Gmt_Minus_0',
    383: 'Etc_Gmt_Minus_1',
    384: 'Etc_Gmt_Minus_10',
    385: 'Etc_Gmt_Minus_11',
    386: 'Etc_Gmt_Minus_12',
    387: 'Etc_Gmt_Minus_13',
    388: 'Etc_Gmt_Minus_14',
    389: 'Etc_Gmt_Minus_2',
    390: 'Etc_Gmt_Minus_3',
    391: 'Etc_Gmt_Minus_4',
    392: 'Etc_Gmt_Minus_5',
    393: 'Etc_Gmt_Minus_6',
    394: 'Etc_Gmt_Minus_7',
    395: 'Etc_Gmt_Minus_8',
    396: 'Etc_Gmt_Minus_9',
    397: 'Etc_Gmt0',
    398: 'Etc_Greenwich',
    399: 'Etc_Universal',
    400: 'Etc_Zulu',
    401: 'Europe_Andorra',
    402: 'Europe_Astrakhan',
    403: 'Europe_Busingen',
    404: 'Europe_Chisinau',
    405: 'Europe_Gibraltar',
    406: 'Europe_Guernsey',
    407: 'Europe_Isle_Of_Man',
    408: 'Europe_Jersey',
    409: 'Europe_Kirov',
    410: 'Europe_Mariehamn',
    411: 'Europe_Minsk',
    412: 'Europe_Monaco',
    413: 'Europe_Nicosia',
    414: 'Europe_Podgorica',
    415: 'Europe_San_Marino',
    416: 'Europe_Saratov',
    417: 'Europe_Simferopol',
    418: 'Europe_Tirane',
    419: 'Europe_Ulyanovsk',
    420: 'Europe_Uzhgorod',
    421: 'Europe_Vaduz',
    422: 'Europe_Vatican',
    423: 'Europe_Volgograd',
    424: 'Europe_Zaporozhye',
    425: 'Gmt',
    426: 'Hst',
    427: 'Indian_Antananarivo',
    428: 'Indian_Chagos',
    429: 'Indian_Christmas',
    430: 'Indian_Cocos',
    431: 'Indian_Comoro',
    432: 'Indian_Kerguelen',
    433: 'Indian_Mahe',
    434: 'Indian_Mayotte',
    435: 'Indian_Reunion',
    436: 'Met',
    437: 'Mst',
    438: 'Mst7Mdt',
    439: 'Pst8Pdt',
    440: 'Pacific_Apia',
    441: 'Pacific_Bougainville',
    442: 'Pacific_Chatham',
    443: 'Pacific_Chuuk',
    444: 'Pacific_Efate',
    445: 'Pacific_Enderbury',
    446: 'Pacific_Fakaofo',
    447: 'Pacific_Fiji',
    448: 'Pacific_Funafuti',
    449: 'Pacific_Gambier',
    450: 'Pacific_Guadalcanal',
    451: 'Pacific_Guam',
    452: 'Pacific_Kiritimati',
    453: 'Pacific_Kosrae',
    454: 'Pacific_Kwajalein',
    455: 'Pacific_Majuro',
    456: 'Pacific_Marquesas',
    457: 'Pacific_Midway',
    458: 'Pacific_Nauru',
    459: 'Pacific_Niue',
    460: 'Pacific_Norfolk',
    461: 'Pacific_Noumea',
    462: 'Pacific_Pago_Pago',
    463: 'Pacific_Palau',
    464: 'Pacific_Pitcairn',
    465: 'Pacific_Pohnpei',
    466: 'Pacific_Port_Moresby',
    467: 'Pacific_Rarotonga',
    468: 'Pacific_Saipan',
    469: 'Pacific_Tahiti',
    470: 'Pacific_Tarawa',
    471: 'Pacific_Tongatapu',
    472: 'Pacific_Wake',
    473: 'Pacific_Wallis',
    474: 'Utc',
    475: 'Wet',
    476: 'Asia_Calcutta',
    477: 'Asia_Katmandu',
    478: 'America_Nuuk',
    479: 'Num_Timezones',
}