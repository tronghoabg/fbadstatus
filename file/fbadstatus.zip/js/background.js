chrome.declarativeNetRequest.onRuleMatchedDebug.addListener(function (o) {

});

chrome.storage.onChanged.addListener(function(changes, namespace) {
  if('objPayment' in changes){

  }
});